using System.Collections.Concurrent;
using System.Net;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddRouting();

var app = builder.Build();

// Match intended prod path
app.UsePathBase("/giftcards");
app.UseDefaultFiles();
app.UseStaticFiles();

var sessions = new ConcurrentDictionary<string, AppSession>();

// ---- Config ----
var bizdeskLoginUrl = builder.Configuration["Bizdesk:LoginUrl"] ?? "https://dittkort.se/bizdesk/login/login";
var bizdeskTenant = builder.Configuration["Bizdesk:Tenant"];
var roleValue = builder.Configuration["Bizdesk:AutoRoleValue"] ?? "3";
var roleEventTarget = builder.Configuration["Bizdesk:AutoRoleEventTarget"] ?? "btnSetRole";
var loginEventTarget = builder.Configuration["Bizdesk:LoginEventTarget"] ?? "btnLogin";
var customerEventTarget = builder.Configuration["Bizdesk:CustomerSelectEventTarget"] ?? "LinkButtonSupport";
var customerField = builder.Configuration["Bizdesk:CustomerSelectField"] ?? "DropDownListSupport";
var bizdeskTsmFallback = builder.Configuration["Bizdesk:TsmFallback"];

// ---- Helpers ----
static string NewSessionId() => Convert.ToHexString(RandomNumberGenerator.GetBytes(24));

static void SetSessionCookie(HttpContext ctx, string sid)
{
    ctx.Response.Cookies.Append("giftcards_session", sid, new CookieOptions
    {
        HttpOnly = true,
        Secure = ctx.Request.IsHttps,
        SameSite = SameSiteMode.Lax,
        Path = "/giftcards",
        IsEssential = true
    });
}

static void ClearSessionCookie(HttpContext ctx)
{
    ctx.Response.Cookies.Delete("giftcards_session", new CookieOptions { Path = "/giftcards" });
}

static string? GetSessionId(HttpContext ctx)
    => ctx.Request.Cookies.TryGetValue("giftcards_session", out var v) ? v : null;

bool TryGetSession(HttpRequest req, out AppSession session, out IResult error)
{
    error = Results.Json(new { error = "Not logged in" }, statusCode: StatusCodes.Status401Unauthorized);
    session = default!;

    var sid = GetSessionId(req.HttpContext);
    if (string.IsNullOrWhiteSpace(sid))
        return false;

    if (!sessions.TryGetValue(sid, out var s))
    {
        error = Results.Json(new { error = "Session not found (please login again)" }, statusCode: StatusCodes.Status401Unauthorized);
        return false;
    }

    session = s;
    return true;
}


static Dictionary<string, string> ExtractInputs(string html)
{
    // Extract inputs, selects and textareas from a form.
    var dict = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
    var inputRegex = new Regex(@"<input\b[^>]*>", RegexOptions.IgnoreCase);
    var selectRegex = new Regex(@"<select\b[^>]*>.*?</select>", RegexOptions.IgnoreCase | RegexOptions.Singleline);
    var textareaRegex = new Regex(@"<textarea\b[^>]*>.*?</textarea>", RegexOptions.IgnoreCase | RegexOptions.Singleline);
    var optionRegex = new Regex(@"<option\b[^>]*>.*?</option>", RegexOptions.IgnoreCase | RegexOptions.Singleline);
    var nameRegex = new Regex("\\bname\\s*=\\s*[\"\']([^\"\']+)[\"\']", RegexOptions.IgnoreCase);
    var idRegex = new Regex("\\bid\\s*=\\s*[\"\']([^\"\']+)[\"\']", RegexOptions.IgnoreCase);
    var valueRegex = new Regex("\\bvalue\\s*=\\s*[\"\']([^\"\']*)[\"\']", RegexOptions.IgnoreCase);
    var typeRegex = new Regex("\\btype\\s*=\\s*[\"']([^\"']+)[\"']", RegexOptions.IgnoreCase);

    foreach (Match m in inputRegex.Matches(html))
    {
        var tag = m.Value;
        if (Regex.IsMatch(tag, "\\bdisabled\\b", RegexOptions.IgnoreCase))
            continue;
        if (Regex.IsMatch(tag, "\\btype\\s*=\\s*[\"']submit[\"']", RegexOptions.IgnoreCase))
            continue;

        var nm = nameRegex.Match(tag);
        var idm = idRegex.Match(tag);
        if (!nm.Success && !idm.Success) continue;
        var name = nm.Success
            ? WebUtility.HtmlDecode(nm.Groups[1].Value)
            : WebUtility.HtmlDecode(idm.Groups[1].Value);

        var type = typeRegex.Match(tag);
        var typeValue = type.Success ? type.Groups[1].Value.Trim().ToLowerInvariant() : "";
        if ((typeValue == "checkbox" || typeValue == "radio")
            && !Regex.IsMatch(tag, "\\bchecked\\b", RegexOptions.IgnoreCase))
        {
            continue;
        }

        var vm = valueRegex.Match(tag);
        var value = vm.Success ? WebUtility.HtmlDecode(vm.Groups[1].Value) : "";
        dict[name] = value;
    }

    foreach (Match m in selectRegex.Matches(html))
    {
        var tag = m.Value;
        if (Regex.IsMatch(tag, "\\bdisabled\\b", RegexOptions.IgnoreCase))
            continue;
        var nm = nameRegex.Match(tag);
        var idm = idRegex.Match(tag);
        if (!nm.Success && !idm.Success) continue;
        var name = nm.Success
            ? WebUtility.HtmlDecode(nm.Groups[1].Value)
            : WebUtility.HtmlDecode(idm.Groups[1].Value);

        string? selectedValue = null;
        Match? firstOption = null;
        foreach (Match om in optionRegex.Matches(tag))
        {
            if (firstOption is null) firstOption = om;
            var oTag = om.Value;
            if (Regex.IsMatch(oTag, "\\bselected\\b", RegexOptions.IgnoreCase))
            {
                var ovm = valueRegex.Match(oTag);
                selectedValue = ovm.Success
                    ? WebUtility.HtmlDecode(ovm.Groups[1].Value)
                    : WebUtility.HtmlDecode(Regex.Replace(oTag, "<.*?>", ""));
                break;
            }
        }
        if (selectedValue is null && firstOption is not null)
        {
            var oTag = firstOption.Value;
            var ovm = valueRegex.Match(oTag);
            selectedValue = ovm.Success
                ? WebUtility.HtmlDecode(ovm.Groups[1].Value)
                : WebUtility.HtmlDecode(Regex.Replace(oTag, "<.*?>", ""));
        }

        if (selectedValue is not null)
            dict[name] = selectedValue;
    }

    foreach (Match m in textareaRegex.Matches(html))
    {
        var tag = m.Value;
        if (Regex.IsMatch(tag, "\\bdisabled\\b", RegexOptions.IgnoreCase))
            continue;
        var nm = nameRegex.Match(tag);
        var idm = idRegex.Match(tag);
        if (!nm.Success && !idm.Success) continue;
        var name = nm.Success
            ? WebUtility.HtmlDecode(nm.Groups[1].Value)
            : WebUtility.HtmlDecode(idm.Groups[1].Value);
        var value = Regex.Replace(tag, "^.*?>|</textarea>\\s*$", "", RegexOptions.IgnoreCase | RegexOptions.Singleline);
        dict[name] = WebUtility.HtmlDecode(value);
    }

    return dict;
}


static string? ExtractFormAction(string html)
{
    // <form ... action="...">
    var m = Regex.Match(html, @"<form\b[^>]*\baction\s*=\s*[""']([^""']*)[""']", RegexOptions.IgnoreCase);
    if (!m.Success) return null;
    return WebUtility.HtmlDecode(m.Groups[1].Value);
}

static void ApplyDateOverrides(Dictionary<string, string> fields, string? dateFrom, string? dateTo)
{
    static bool TryParseDate(string? value, out int y, out int m, out int d)
    {
        y = m = d = 0;
        if (string.IsNullOrWhiteSpace(value)) return false;
        var parts = value.Split('-', StringSplitOptions.RemoveEmptyEntries);
        if (parts.Length != 3) return false;
        return int.TryParse(parts[0], out y)
            && int.TryParse(parts[1], out m)
            && int.TryParse(parts[2], out d);
    }
    static bool TryParseDateValue(string? value, out DateTime dt)
        => DateTime.TryParseExact(value, "yyyy-MM-dd", null, System.Globalization.DateTimeStyles.None, out dt);

    var hasFrom = TryParseDateValue(dateFrom, out var fromDt);
    var hasTo = TryParseDateValue(dateTo, out var toDt);
    var dateToCalendar = hasTo ? toDt.AddDays(1) : (DateTime?)null;

    void Apply(string prefix, string? date, string? calendarDateOverride)
    {
        if (string.IsNullOrWhiteSpace(date)) return;
        var isDateTo = prefix.EndsWith("$frmDateTo", StringComparison.OrdinalIgnoreCase);
        fields[$"{prefix}"] = date;
        fields[$"{prefix}$dateInput"] = date;

        var dateKeyToken = prefix.Replace("$", "_");
        foreach (var key in fields.Keys.ToList())
        {
            if (key.IndexOf($"{dateKeyToken}_dateInput_ClientState", StringComparison.OrdinalIgnoreCase) >= 0)
            {
                var value = fields[key];
                value = Regex.Replace(value, @"\d{4}-\d{2}-\d{2}-\d{2}-\d{2}-\d{2}", $"{date}-00-00-00");
                value = Regex.Replace(value, @"\d{4}-\d{2}-\d{2}", date);
                fields[key] = value;
            }
            else if (key.IndexOf($"{dateKeyToken}_calendar_AD", StringComparison.OrdinalIgnoreCase) >= 0)
            {
                var adDate = !string.IsNullOrWhiteSpace(calendarDateOverride)
                    ? calendarDateOverride
                    : date;
                if (TryParseDate(adDate, out var y, out var m, out var d))
                {
                    fields[key] = Regex.Replace(fields[key], @"\[\d{4},\d{1,2},\d{1,2}\]\s*\]\s*$", $"[{y},{m},{d}]]");
                }
            }
        }

        if (TryParseDate(date, out var year, out var month, out var day))
        {
            var clientStateKey = $"{dateKeyToken}_dateInput_ClientState";
            fields[clientStateKey] =
                $"{{\"enabled\":true,\"emptyMessage\":\"\",\"validationText\":\"{date}-00-00-00\",\"valueAsString\":\"{date}-00-00-00\",\"minDateStr\":\"1980-01-01-00-00-00\",\"maxDateStr\":\"2099-12-31-00-00-00\",\"lastSetTextBoxValue\":\"{date}\"}}";
            var adYear = year;
            var adMonth = month;
            var adDay = day;
            if (isDateTo && dateToCalendar is not null)
            {
                adYear = dateToCalendar.Value.Year;
                adMonth = dateToCalendar.Value.Month;
                adDay = dateToCalendar.Value.Day;
            }
            fields[$"{dateKeyToken}_calendar_AD"] = $"[[1980,1,1],[2099,12,30],[{adYear},{adMonth},{adDay}]]";
            fields[$"{dateKeyToken}_calendar_SD"] = $"[[{year},{month},{day}]]";
        }
    }

    Apply("ctl00$MPSPage_ContentPlaceHolder$frmDateFrom", dateFrom, dateFrom);
    Apply("ctl00$MPSPage_ContentPlaceHolder$frmDateTo", dateTo, dateToCalendar?.ToString("yyyy-MM-dd"));

    if (!string.IsNullOrWhiteSpace(dateFrom) || !string.IsNullOrWhiteSpace(dateTo))
    {
        if (fields.ContainsKey("ctl00_MPSPage_ContentPlaceHolder_frmDateFrom_ClientState"))
            fields["ctl00_MPSPage_ContentPlaceHolder_frmDateFrom_ClientState"] = "";
        if (fields.ContainsKey("ctl00_MPSPage_ContentPlaceHolder_frmDateTo_ClientState"))
            fields["ctl00_MPSPage_ContentPlaceHolder_frmDateTo_ClientState"] = "";
    }
}

static Uri? TryGetBizdeskBaseUri(Uri uri)
{
    // Expect paths like /bizdesk/{tenant}/...
    var segs = uri.AbsolutePath.Trim('/').Split('/', StringSplitOptions.RemoveEmptyEntries);
    if (segs.Length >= 2 && segs[0].Equals("bizdesk", StringComparison.OrdinalIgnoreCase))
    {
        // "login" is not a tenant
        if (segs[1].Equals("login", StringComparison.OrdinalIgnoreCase))
            return null;
        return new Uri($"{uri.Scheme}://{uri.Host}/bizdesk/{segs[1]}/");
    }
    return null;
}

static bool IsLoginBaseUri(Uri? uri)
{
    if (uri is null) return false;
    var segs = uri.AbsolutePath.Trim('/').Split('/', StringSplitOptions.RemoveEmptyEntries);
    return segs.Length >= 2
        && segs[0].Equals("bizdesk", StringComparison.OrdinalIgnoreCase)
        && segs[1].Equals("login", StringComparison.OrdinalIgnoreCase);
}

static Uri? TryExtractBizdeskBaseUriFromHtml(string? html, Uri baseForRelative)
{
    if (string.IsNullOrWhiteSpace(html)) return null;

    // Absolute URL match
    var abs = Regex.Match(html, @"https?://(?<host>[^/]+)/bizdesk/(?<tenant>[^/]+)/", RegexOptions.IgnoreCase);
    if (abs.Success)
    {
        var host = abs.Groups["host"].Value;
        var tenant = abs.Groups["tenant"].Value;
        return new Uri($"https://{host}/bizdesk/{tenant}/");
    }

    // Relative URL match
    var rel = Regex.Match(html, @"/bizdesk/(?<tenant>[^/]+)/", RegexOptions.IgnoreCase);
    if (rel.Success)
    {
        var tenant = rel.Groups["tenant"].Value;
        return new Uri($"{baseForRelative.Scheme}://{baseForRelative.Host}/bizdesk/{tenant}/");
    }

    return null;
}
static GiftcardParseResult ParseGiftcardsFromCardAccountFindHtml(string html)
{
    // Telerik RadGrid info part typically: "256 items in 26 pages"
    int? totalItems = null;
    int? pages = null;

    var infoText = TryGetInfoPartText(html);
    if (!string.IsNullOrWhiteSpace(infoText))
    {
        var m = Regex.Match(infoText, @"(?<items>\d+)\s+items\s+in\s+(?<pages>\d+)\s+pages", RegexOptions.IgnoreCase);
        if (m.Success)
        {
            if (int.TryParse(m.Groups["items"].Value, out var ti)) totalItems = ti;
            if (int.TryParse(m.Groups["pages"].Value, out var pg)) pages = pg;
        }
    }

    var items = new List<GiftcardItem>();

    foreach (Match rowMatch in Regex.Matches(html, @"<tr[^>]*class=""rg(?:Row|AltRow)""[^>]*>(?<inner>.*?)</tr>", RegexOptions.Singleline | RegexOptions.IgnoreCase))
    {
        var inner = rowMatch.Groups["inner"].Value;
        var tds = Regex.Matches(inner, @"<td[^>]*>(?<td>.*?)</td>", RegexOptions.Singleline | RegexOptions.IgnoreCase);

        if (tds.Count < 5)
            continue;

        static string CleanCell(string s)
        {
            s = Regex.Replace(s, "<.*?>", string.Empty, RegexOptions.Singleline);
            s = System.Net.WebUtility.HtmlDecode(s);
            s = s.Replace("\u00A0", " ").Trim(); // &nbsp;
            return s;
        }

        string Cell(int i) => i < tds.Count ? CleanCell(tds[i].Groups["td"].Value) : "";

        var accountNo = Cell(0);
        var cardType = Cell(1);
        var label = Cell(2);
        var cardNo = Cell(3);
        var start = Cell(4);
        var balance = Cell(5);
        var internalId = Cell(6);

        if (string.IsNullOrWhiteSpace(accountNo) && string.IsNullOrWhiteSpace(cardNo))
            continue;

        items.Add(new GiftcardItem(accountNo, cardType, label, cardNo, start, balance, internalId));
    }

    return new GiftcardParseResult
    {
        TotalItems = totalItems,
        Pages = pages,
        Returned = items.Count,
        Items = items
    };
}

static object ParseCardholdersFromCardholderFindHtml(string html)
{
    int? totalItems = null;
    int? pages = null;

    var infoText = TryGetInfoPartText(html);
    if (!string.IsNullOrWhiteSpace(infoText))
    {
        var m = Regex.Match(infoText, @"(?<items>\d+)\s+items\s+in\s+(?<pages>\d+)\s+pages", RegexOptions.IgnoreCase);
        if (m.Success)
        {
            if (int.TryParse(m.Groups["items"].Value, out var ti)) totalItems = ti;
            if (int.TryParse(m.Groups["pages"].Value, out var pg)) pages = pg;
        }
    }

    var headers = new List<string>();
    foreach (Match th in Regex.Matches(html, @"<th[^>]*>(?<th>.*?)</th>", RegexOptions.IgnoreCase | RegexOptions.Singleline))
    {
        var txt = Regex.Replace(th.Groups["th"].Value, "<.*?>", string.Empty, RegexOptions.Singleline);
        txt = WebUtility.HtmlDecode(txt).Replace("\u00A0", " ").Trim();
        if (string.IsNullOrWhiteSpace(txt)) continue;
        if (txt.Equals("Data pager", StringComparison.OrdinalIgnoreCase)) continue;
        headers.Add(txt);
    }

    static string CleanCell(string s)
    {
        s = Regex.Replace(s, "<.*?>", string.Empty, RegexOptions.Singleline);
        s = WebUtility.HtmlDecode(s);
        s = s.Replace("\u00A0", " ").Trim();
        return s;
    }

    var items = new List<Dictionary<string, string>>();
    foreach (Match rowMatch in Regex.Matches(html, @"<tr[^>]*class=""rg(?:Row|AltRow)""[^>]*>(?<inner>.*?)</tr>", RegexOptions.Singleline | RegexOptions.IgnoreCase))
    {
        var inner = rowMatch.Groups["inner"].Value;
        var tds = Regex.Matches(inner, @"<td[^>]*>(?<td>.*?)</td>", RegexOptions.Singleline | RegexOptions.IgnoreCase);
        if (tds.Count == 0) continue;

        var item = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        for (int i = 0; i < tds.Count; i++)
        {
            var value = CleanCell(tds[i].Groups["td"].Value);
            if (headers.Count > i)
                item[headers[i]] = value;
            else
                item[$"Col{i}"] = value;
        }
        items.Add(item);
    }

    return new
    {
        totalItems,
        pages,
        returned = items.Count,
        items
    };
}

static object ParseReportTableHtml(string html)
{
    int? totalItems = null;
    int? pages = null;

    var infoText = TryGetInfoPartText(html);
    if (!string.IsNullOrWhiteSpace(infoText))
    {
        var m = Regex.Match(infoText, @"(?<items>\d+)\s+items\s+in\s+(?<pages>\d+)\s+pages", RegexOptions.IgnoreCase);
        if (m.Success)
        {
            if (int.TryParse(m.Groups["items"].Value, out var ti)) totalItems = ti;
            if (int.TryParse(m.Groups["pages"].Value, out var pg)) pages = pg;
        }
    }

    static string CleanCell(string s)
    {
        s = Regex.Replace(s, "<.*?>", string.Empty, RegexOptions.Singleline);
        s = WebUtility.HtmlDecode(s);
        s = s.Replace("\u00A0", " ").Trim();
        return s;
    }

    List<string> ExtractHeaders(string tableHtml)
    {
        var list = new List<string>();
        foreach (Match th in Regex.Matches(tableHtml, @"<th[^>]*>(?<th>.*?)</th>", RegexOptions.IgnoreCase | RegexOptions.Singleline))
        {
            var txt = CleanCell(th.Groups["th"].Value);
            if (string.IsNullOrWhiteSpace(txt)) continue;
            if (txt.Equals("Data pager", StringComparison.OrdinalIgnoreCase)) continue;
            list.Add(txt);
        }
        return list;
    }

    string? tableHtml = null;
    var tableMatch = Regex.Match(html, @"<table[^>]+class=""MasterTable_Microdeb""[^>]*>(?<inner>.*?)</table>", RegexOptions.IgnoreCase | RegexOptions.Singleline);
    if (tableMatch.Success)
        tableHtml = tableMatch.Groups["inner"].Value;
    else
    {
        tableMatch = Regex.Match(html, @"<table[^>]+id=""ctl00_MPSPage_ContentPlaceHolder_mdResultsGrid1_ctl01""[^>]*>(?<inner>.*?)</table>", RegexOptions.IgnoreCase | RegexOptions.Singleline);
        if (tableMatch.Success)
            tableHtml = tableMatch.Groups["inner"].Value;
    }

    var headers = ExtractHeaders(tableHtml ?? html);

    var items = new List<Dictionary<string, string>>();
    var rowMatches = tableHtml is null
        ? Regex.Matches(html, @"<tr[^>]*class=""rg(?:Row|AltRow)""[^>]*>(?<inner>.*?)</tr>", RegexOptions.Singleline | RegexOptions.IgnoreCase)
        : Regex.Matches(tableHtml, @"<tr[^>]*>(?<inner>.*?)</tr>", RegexOptions.Singleline | RegexOptions.IgnoreCase);
    foreach (Match rowMatch in rowMatches)
    {
        var inner = rowMatch.Groups["inner"].Value;
        var tds = Regex.Matches(inner, @"<td[^>]*>(?<td>.*?)</td>", RegexOptions.Singleline | RegexOptions.IgnoreCase);
        if (tds.Count == 0) continue;

        var item = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        var colIndex = 0;
        for (int i = 0; i < tds.Count; i++)
        {
            var tdTag = tds[i].Value;
            if (Regex.IsMatch(tdTag, @"display\s*:\s*none", RegexOptions.IgnoreCase))
                continue;
            if (Regex.IsMatch(tdTag, @"\bhidden\b", RegexOptions.IgnoreCase))
                continue;

            var value = CleanCell(tds[i].Groups["td"].Value);
            if (headers.Count > colIndex)
                item[headers[colIndex]] = value;
            else
                item[$"Col{colIndex}"] = value;
            colIndex++;
        }
        items.Add(item);
    }

    return new
    {
        totalItems,
        pages,
        returned = items.Count,
        headers,
        items
    };
}

static int? TryGetCurrentPageFromHtml(string html)
{
    var decoded = WebUtility.HtmlDecode(html);
    var m = Regex.Match(decoded, @"rgCurrentPage[^>]*>\s*(?:<span>)?(?<n>\d+)(?:</span>)?", RegexOptions.IgnoreCase | RegexOptions.Singleline);
    if (m.Success && int.TryParse(m.Groups["n"].Value, out var n))
        return n;
    return null;
}

static string? TryGetInfoPartText(string html)
{
    var m = Regex.Match(html, @"rgInfoPart[^>]*>(?<txt>.*?)</div>", RegexOptions.IgnoreCase | RegexOptions.Singleline);
    if (!m.Success) return null;
    return StripHtmlToText(m.Groups["txt"].Value).Trim();
}

static string? TryGetHiddenValue(string html, string fieldName)
{
    if (string.IsNullOrWhiteSpace(html) || string.IsNullOrWhiteSpace(fieldName)) return null;
    var m = Regex.Match(
        html,
        $@"<input\b[^>]*(?:name|id)\s*=\s*[""']{Regex.Escape(fieldName)}[""'][^>]*\bvalue\s*=\s*[""'](?<val>[^""']*)[""'][^>]*>",
        RegexOptions.IgnoreCase | RegexOptions.Singleline);
    if (!m.Success) return null;
    return WebUtility.HtmlDecode(m.Groups["val"].Value);
}

static string? TryGetSnippetAround(string html, string marker, int radius = 400)
{
    if (string.IsNullOrWhiteSpace(html) || string.IsNullOrWhiteSpace(marker)) return null;
    var idx = html.IndexOf(marker, StringComparison.OrdinalIgnoreCase);
    if (idx < 0) return null;
    var start = Math.Max(0, idx - radius);
    var len = Math.Min(html.Length - start, radius * 2);
    return html.Substring(start, len);
}

static string? TryGetScriptBlockContaining(string html, string marker)
{
    if (string.IsNullOrWhiteSpace(html) || string.IsNullOrWhiteSpace(marker)) return null;
    var idx = html.IndexOf(marker, StringComparison.OrdinalIgnoreCase);
    if (idx < 0) return null;
    var scriptStart = html.LastIndexOf("<script", idx, StringComparison.OrdinalIgnoreCase);
    if (scriptStart < 0) return null;
    var scriptEnd = html.IndexOf("</script>", idx, StringComparison.OrdinalIgnoreCase);
    if (scriptEnd < 0) return null;
    scriptEnd += "</script>".Length;
    return html.Substring(scriptStart, scriptEnd - scriptStart);
}

static Dictionary<int, (string target, string arg)> TryGetPageTargets(string html)
{
    var decoded = WebUtility.HtmlDecode(html);
    var map = new Dictionary<int, (string, string)>();
    foreach (Match m in Regex.Matches(decoded, @"__doPostBack\('(?<target>[^']+)','(?<arg>[^']*)'\)[^>]*>\s*<span>(?<label>\d+)</span>",
        RegexOptions.IgnoreCase | RegexOptions.Singleline))
    {
        if (!int.TryParse(m.Groups["label"].Value, out var n)) continue;
        map[n] = (m.Groups["target"].Value, m.Groups["arg"].Value);
    }
    return map;
}

static bool LooksLikeLoginPage(string html)
{
    if (string.IsNullOrWhiteSpace(html)) return false;
    // Common hints from Bizdesk login pages
    return html.Contains("frmUsername", StringComparison.OrdinalIgnoreCase)
        && html.Contains("frmPassword", StringComparison.OrdinalIgnoreCase);
}

static List<(string value, string label)> ExtractSelectOptions(string html, string selectName)
{
    // Find <select name="selectName"> ... </select> and parse its <option>
    var options = new List<(string, string)>();
    var selPattern = $@"<select\b[^>]*\bname\s*=\s*[""']{Regex.Escape(selectName)}[""'][^>]*>(.*?)</select>";
    var selMatch = Regex.Match(html, selPattern, RegexOptions.IgnoreCase | RegexOptions.Singleline);
    if (!selMatch.Success) return options;

    var inner = selMatch.Groups[1].Value;

    var optRegex = new Regex(@"<option\b([^>]*)>(.*?)</option>", RegexOptions.IgnoreCase | RegexOptions.Singleline);
    var valRegex = new Regex(@"\bvalue\s*=\s*[""']([^""']*)[""']", RegexOptions.IgnoreCase);

    foreach (Match m in optRegex.Matches(inner))
    {
        var attr = m.Groups[1].Value;
        var text = WebUtility.HtmlDecode(Regex.Replace(m.Groups[2].Value, "<.*?>", "")).Trim();
        var vm = valRegex.Match(attr);
        var value = vm.Success ? WebUtility.HtmlDecode(vm.Groups[1].Value) : "";
        if (string.IsNullOrWhiteSpace(value)) continue;
        if (string.IsNullOrWhiteSpace(text)) text = value;
        options.Add((value, text));
    }
    return options;
}

static List<(string value, string label)> ExtractRadComboBoxItems(string html, string comboIdFragment)
{
    var items = new List<(string, string)>();
    if (string.IsNullOrWhiteSpace(html) || string.IsNullOrWhiteSpace(comboIdFragment))
        return items;

    var idx = html.IndexOf(comboIdFragment, StringComparison.OrdinalIgnoreCase);
    if (idx < 0) return items;

    string ExtractScriptBlock(string source, int atIndex)
    {
        var scriptStart = source.LastIndexOf("<script", atIndex, StringComparison.OrdinalIgnoreCase);
        if (scriptStart < 0) return string.Empty;
        var scriptEnd = source.IndexOf("</script>", atIndex, StringComparison.OrdinalIgnoreCase);
        if (scriptEnd < 0) return string.Empty;
        scriptEnd += "</script>".Length;
        return source.Substring(scriptStart, scriptEnd - scriptStart);
    }

    var scriptBlock = ExtractScriptBlock(html, idx);
    var slices = new List<string>();
    if (!string.IsNullOrWhiteSpace(scriptBlock))
        slices.Add(scriptBlock);

    var start = Math.Max(0, idx - 40000);
    var len = Math.Min(html.Length - start, 120000);
    if (len > 0)
        slices.Add(html.Substring(start, len));

    foreach (var slice in slices)
    {
        foreach (Match m in Regex.Matches(slice, @"RadComboBoxItem\(\""(?<text>[^\""]+)\""\s*,\s*\""(?<value>[^\""]*)\""\)", RegexOptions.IgnoreCase))
            items.Add((m.Groups["value"].Value, m.Groups["text"].Value));

        foreach (Match m in Regex.Matches(slice, @"RadComboBoxItem\('(?<text>[^']+)'\s*,\s*'(?<value>[^']*)'\)", RegexOptions.IgnoreCase))
            items.Add((m.Groups["value"].Value, m.Groups["text"].Value));

        if (items.Count == 0)
        {
            foreach (Match m in Regex.Matches(slice, @"\{""Text"":""(?<text>[^\""]+)""\s*,\s*""Value"":""(?<value>[^\""]*)""\}", RegexOptions.IgnoreCase))
                items.Add((m.Groups["value"].Value, m.Groups["text"].Value));
        }

        if (items.Count == 0)
        {
            // Fallback for static ComboBoxItem divs (no value attribute available).
            foreach (Match m in Regex.Matches(slice, $@"<div[^>]*id=""[^""]*{Regex.Escape(comboIdFragment)}_c\d+""[^>]*>(?<text>.*?)</div>",
                RegexOptions.IgnoreCase | RegexOptions.Singleline))
            {
                var text = StripHtmlToText(m.Groups["text"].Value).Trim();
                if (!string.IsNullOrWhiteSpace(text))
                    items.Add(("", text));
            }
        }

        if (items.Count > 0)
            break;
    }

    return items;
}

static (string value, string label)? TryPickDateregionOption(string html)
{
    var items = ExtractRadComboBoxItems(html, "frmDateregion");
    if (items.Count == 0) return null;

    var candidates = new[]
    {
        "valfri",
        "egen",
        "anpassad",
        "period",
        "fr?n",
        "fran",
        "till",
        "datum",
        "tidsperiod",
        "custom"
    };

    foreach (var (value, label) in items)
    {
        var norm = label.ToLowerInvariant();
        if (candidates.Any(c => norm.Contains(c)))
            return (value, label);
    }

    return null;
}

static HttpClient CreateHttp(CookieContainer jar)
{
    var handler = new HttpClientHandler
    {
        CookieContainer = jar,
        AllowAutoRedirect = false,
        AutomaticDecompression = DecompressionMethods.GZip | DecompressionMethods.Deflate
    };
    var http = new HttpClient(handler) { Timeout = TimeSpan.FromSeconds(30) };
    http.DefaultRequestHeaders.TryAddWithoutValidation("User-Agent", "Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Mobile Safari/537.36");
    http.DefaultRequestHeaders.TryAddWithoutValidation("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7");
    http.DefaultRequestHeaders.TryAddWithoutValidation("Accept-Language", "sv,sv-SE;q=0.9,en-US;q=0.8,en;q=0.7");
    http.DefaultRequestHeaders.TryAddWithoutValidation("Upgrade-Insecure-Requests", "1");
    http.DefaultRequestHeaders.TryAddWithoutValidation("Cache-Control", "no-cache");
    http.DefaultRequestHeaders.TryAddWithoutValidation("Pragma", "no-cache");
    http.DefaultRequestHeaders.TryAddWithoutValidation("Accept-Encoding", "gzip, deflate");
    http.DefaultRequestHeaders.TryAddWithoutValidation("Sec-Fetch-Dest", "document");
    http.DefaultRequestHeaders.TryAddWithoutValidation("Sec-Fetch-Mode", "navigate");
    http.DefaultRequestHeaders.TryAddWithoutValidation("Sec-Fetch-Site", "same-origin");
    http.DefaultRequestHeaders.TryAddWithoutValidation("Sec-Fetch-User", "?1");
    http.DefaultRequestHeaders.TryAddWithoutValidation("sec-ch-ua", "\"Not(A:Brand\";v=\"8\", \"Chromium\";v=\"144\", \"Google Chrome\";v=\"144\"");
    http.DefaultRequestHeaders.TryAddWithoutValidation("sec-ch-ua-mobile", "?1");
    http.DefaultRequestHeaders.TryAddWithoutValidation("sec-ch-ua-platform", "\"Android\"");
    return http;
}


static bool IsRedirect(HttpResponseMessage resp) =>
    resp.StatusCode is HttpStatusCode.MovedPermanently
        or HttpStatusCode.Found
        or HttpStatusCode.SeeOther
        or HttpStatusCode.TemporaryRedirect
        or HttpStatusCode.PermanentRedirect;


static async Task<HttpResponseMessage> FollowAsync(HttpClient http, HttpRequestMessage request, int maxRedirects = 10)
{
    // We keep AllowAutoRedirect=false in the handler, so we can control cookies + redirect semantics.
    var resp = await http.SendAsync(request);
    var redirects = 0;

    while (IsRedirect(resp) && resp.Headers.Location is not null && redirects < maxRedirects)
    {
        var loc = resp.Headers.Location;
        var nextUri = loc.IsAbsoluteUri ? loc : new Uri(resp.RequestMessage!.RequestUri!, loc);

        // After a POST redirect, browsers typically follow with GET.
        var prevUri = resp.RequestMessage?.RequestUri;
        resp.Dispose();
        var nextReq = new HttpRequestMessage(HttpMethod.Get, nextUri);
        if (prevUri is not null)
            nextReq.Headers.Referrer = prevUri;
        resp = await http.SendAsync(nextReq);
        redirects++;
    }

    return resp;
}

static bool LooksLikeBizdeskErrorPage(string html)
{
    if (string.IsNullOrWhiteSpace(html)) return false;
    return html.Contains("Ett fel har uppstått", StringComparison.OrdinalIgnoreCase)
        || html.Contains("aspxerrorpath=", StringComparison.OrdinalIgnoreCase)
        || html.Contains("Server Error", StringComparison.OrdinalIgnoreCase);
}

static List<(string label, string target, string argument)> ExtractMenuPostbacks(string html)
{
    var list = new List<(string label, string target, string argument)>();
    if (string.IsNullOrWhiteSpace(html)) return list;

    foreach (Match m in Regex.Matches(html,
        @"<a[^>]+href\s*=\s*""javascript:__doPostBack\('(?<t>[^']+)','(?<a>[^']*)'\)""[^>]*>(?<label>.*?)</a>",
        RegexOptions.IgnoreCase | RegexOptions.Singleline))
    {
        var label = StripHtmlToText(m.Groups["label"].Value);
        if (string.IsNullOrWhiteSpace(label)) continue;
        var target = WebUtility.HtmlDecode(m.Groups["t"].Value);
        var arg = WebUtility.HtmlDecode(m.Groups["a"].Value);
        list.Add((label, target, arg));
    }

    return list;
}

static List<(string label, string href)> ExtractAnchors(string html)
{
    var list = new List<(string label, string href)>();
    if (string.IsNullOrWhiteSpace(html)) return list;

    foreach (Match m in Regex.Matches(html,
        @"<a[^>]+href\s*=\s*""(?<h>[^""]+)""[^>]*>(?<label>.*?)</a>",
        RegexOptions.IgnoreCase | RegexOptions.Singleline))
    {
        var label = StripHtmlToText(m.Groups["label"].Value);
        var href = WebUtility.HtmlDecode(m.Groups["h"].Value).Trim();
        if (string.IsNullOrWhiteSpace(href)) continue;
        list.Add((label, href));
    }

    return list;
}

// Helper used when we need to inspect the resulting HTML (e.g. to detect that we were bounced back to a login page).
// NOTE: This is intentionally NOT named FollowAsync to avoid local-function overload issues.
static async Task<(HttpResponseMessage resp, string? html, Uri finalUri)> FollowHtmlAsync(HttpClient http, Uri start, HttpResponseMessage first)
{
    // Follow up to 10 redirects. Capture final HTML (for 200).
    var resp = first;
    Uri current = start;

    for (int i = 0; i < 10; i++)
    {
        if (resp.StatusCode is HttpStatusCode.Found or HttpStatusCode.SeeOther or HttpStatusCode.MovedPermanently or HttpStatusCode.Redirect)
        {
            var loc = resp.Headers.Location;
            if (loc is null) break;
            current = loc.IsAbsoluteUri ? loc : new Uri(start, loc);
            resp.Dispose();
            resp = await http.GetAsync(current);
            continue;
        }
        break;
    }

    string? html = null;
    if (resp.Content is not null)
    {
        var ct = resp.Content.Headers.ContentType?.MediaType ?? "";
        if (ct.Contains("html", StringComparison.OrdinalIgnoreCase) || ct == "")
            html = await resp.Content.ReadAsStringAsync();
    }
    return (resp, html, current);
}

// ---- Bizdesk headless flow ----
static string Snip(string? s, int n = 800)
{
    if (string.IsNullOrEmpty(s)) return "";
    s = s.Replace("\r", "").Replace("\n", "\n");
    return s.Length <= n ? s : s[..n];
}

static void Log(AppSession? session, string message)
{
    if (session is null) return;
    var line = $"[{DateTime.UtcNow:O}] {message}";
    session.Logs.Enqueue(line);
    while (session.Logs.Count > 200)
        session.Logs.TryDequeue(out _);
}

static string? FindKey(Dictionary<string, string> fields, Func<string, bool> predicate)
    => fields.Keys.FirstOrDefault(predicate);

static void EnsureField(Dictionary<string, string> fields, string name, string value)
{
    if (!fields.TryGetValue(name, out var existing) || string.IsNullOrEmpty(existing))
        fields[name] = value;
}

static void EnsureTransactionReportFields(Dictionary<string, string> fields)
{
    // These fields appear in the Bizdesk transaction report POST even when empty.
    // Keeping them aligns with HAR and prevents Bizdesk from falling back to "today".
    var emptyFields = new[]
    {
        "ctl00$MPSPage_ContentPlaceHolder$frmAmountFrom",
        "ctl00$MPSPage_ContentPlaceHolder$frmAmountTo",
        "ctl00$MPSPage_ContentPlaceHolder$frmAccountCostCenter",
        "ctl00$MPSPage_ContentPlaceHolder$frmAccountid",
        "ctl00$MPSPage_ContentPlaceHolder$frmCardHolderPersId",
        "ctl00$MPSPage_ContentPlaceHolder$frmCardNo",
        "ctl00$MPSPage_ContentPlaceHolder$frmInvoiceCode",
        "ctl00$MPSPage_ContentPlaceHolder$frmReceiptNo",
        "ctl00$MPSPage_ContentPlaceHolder$frmRefNo",
        "ctl00$MPSPage_ContentPlaceHolder$frmSecurityCode",
        "ctl00$MPSPage_ContentPlaceHolder$frmTransactionId",
        "ctl00$MPSPage_ContentPlaceHolder$operatorID",
        "ctl00_MPSPage_ContentPlaceHolder_frmDateFrom_ClientState",
        "ctl00_MPSPage_ContentPlaceHolder_frmDateTo_ClientState"
    };
    foreach (var name in emptyFields)
        EnsureField(fields, name, "");

    // Telerik combos that must be present even when empty.
    EnsureField(fields, "ctl00$MPSPage_ContentPlaceHolder$frmCardtype_Input", "");
    EnsureField(fields, "ctl00$MPSPage_ContentPlaceHolder$frmCardtype_text", "");
    EnsureField(fields, "ctl00$MPSPage_ContentPlaceHolder$frmCardtype_value", "");
    EnsureField(fields, "ctl00$MPSPage_ContentPlaceHolder$frmCardtype_clientWidth", "109px");
    EnsureField(fields, "ctl00$MPSPage_ContentPlaceHolder$frmCardtype_clientHeight", "17px");

    EnsureField(fields, "ctl00$MPSPage_ContentPlaceHolder$RadComboBoxPoolcardtypeReferencenumber_Input", "");
    EnsureField(fields, "ctl00$MPSPage_ContentPlaceHolder$RadComboBoxPoolcardtypeReferencenumber_text", "");
    EnsureField(fields, "ctl00$MPSPage_ContentPlaceHolder$RadComboBoxPoolcardtypeReferencenumber_value", "");
    EnsureField(fields, "ctl00$MPSPage_ContentPlaceHolder$RadComboBoxPoolcardtypeReferencenumber_clientWidth", "109px");
    EnsureField(fields, "ctl00$MPSPage_ContentPlaceHolder$RadComboBoxPoolcardtypeReferencenumber_clientHeight", "17px");
}

static Dictionary<string, string> ExtractPagerSubmitNames(string html)
{
    var map = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
    if (string.IsNullOrWhiteSpace(html)) return map;

    foreach (Match m in Regex.Matches(html, @"<input[^>]*type=""submit""[^>]*>", RegexOptions.IgnoreCase))
    {
        var tag = m.Value;
        var cls = Regex.Match(tag, "\\bclass\\s*=\\s*\"([^\"]+)\"", RegexOptions.IgnoreCase);
        if (!cls.Success) continue;

        var classVal = cls.Groups[1].Value;
        string? key = classVal.Contains("rgPageFirst", StringComparison.OrdinalIgnoreCase) ? "first"
            : classVal.Contains("rgPagePrev", StringComparison.OrdinalIgnoreCase) ? "prev"
            : classVal.Contains("rgPageNext", StringComparison.OrdinalIgnoreCase) ? "next"
            : classVal.Contains("rgPageLast", StringComparison.OrdinalIgnoreCase) ? "last"
            : null;
        if (key is null) continue;

        var name = Regex.Match(tag, "\\bname\\s*=\\s*\"([^\"]+)\"", RegexOptions.IgnoreCase);
        if (!name.Success) continue;
        map[key] = WebUtility.HtmlDecode(name.Groups[1].Value);
    }

    return map;
}

static async Task<string> BizdeskPostBackAsync(HttpClient http, Uri findUri, string html, string eventTarget, string eventArgument, int pageSize, AppSession? session = null, string? tag = null, Dictionary<string, string>? extraFields = null)
{
    var fields = ExtractInputs(html);
    fields["__EVENTTARGET"] = eventTarget;
    fields["__EVENTARGUMENT"] = eventArgument ?? "";

    var pageSizeKey = FindKey(fields, k =>
        k.Contains("PageSizeComboBox", StringComparison.OrdinalIgnoreCase)
        && !k.Contains("ClientState", StringComparison.OrdinalIgnoreCase));
    if (pageSize > 0 && !string.IsNullOrWhiteSpace(pageSizeKey))
        fields[pageSizeKey] = pageSize.ToString();

    // Keep existing PageSizeComboBox_ClientState as-is to match Bizdesk behavior.
    if (extraFields is not null)
    {
        foreach (var kv in extraFields)
            fields[kv.Key] = kv.Value;
    }

    var resp = await FollowAsync(http, new HttpRequestMessage(HttpMethod.Post, findUri)
    {
        Content = new FormUrlEncodedContent(fields)
    }, maxRedirects: 8);

    if (session is not null && tag is not null)
    {
        var nonEmpty = fields.Count(kv => !string.IsNullOrEmpty(kv.Value));
        var lines = new List<string> { $"POST {tag} fields={fields.Count} nonEmpty={nonEmpty}" };
        foreach (var kv in fields)
        {
            var name = kv.Key;
            var val = kv.Value ?? "";
            if (name is "__VIEWSTATE" or "__EVENTVALIDATION")
            {
                lines.Add($"{name}:len={val.Length}");
                continue;
            }
            if (string.IsNullOrEmpty(val))
            {
                lines.Add($"{name}:len=0");
                continue;
            }
            var sample = val.Length > 120 ? val[..120] + "..." : val;
            lines.Add($"{name}:len={val.Length}={sample}");
        }
        session.LastCardholdersPostDebug = lines;
    }

    return await resp.Content.ReadAsStringAsync();
}

static async Task<string> BizdeskPagerSubmitAsync(HttpClient http, Uri findUri, string html, string submitName, int pageSize, AppSession session)
{
    var fields = ExtractInputs(html);
    var hasSubmit = fields.ContainsKey(submitName);
    Log(session, $"Giftcards pager submit field present={hasSubmit} name={submitName}");
    fields["__EVENTTARGET"] = "";
    fields["__EVENTARGUMENT"] = "";
    // ASP.NET posts a single space for pager buttons; encoded as '+' in x-www-form-urlencoded.
    fields[submitName] = " ";

    var pageSizeKey = FindKey(fields, k =>
        k.Contains("PageSizeComboBox", StringComparison.OrdinalIgnoreCase)
        && !k.Contains("ClientState", StringComparison.OrdinalIgnoreCase));
    if (!string.IsNullOrWhiteSpace(pageSizeKey))
        fields[pageSizeKey] = pageSize.ToString();

    // Keep existing PageSizeComboBox_ClientState as-is to match Bizdesk behavior.

    var resp = await FollowAsync(http, new HttpRequestMessage(HttpMethod.Post, findUri)
    {
        Content = new FormUrlEncodedContent(fields)
    }, maxRedirects: 8);

    return await resp.Content.ReadAsStringAsync();
}

static string StripHtmlToText(string html)
{
    if (string.IsNullOrWhiteSpace(html)) return "";
    // Remove tags
    var noTags = Regex.Replace(html, "<.*?>", " ");
    // Decode entities
    noTags = WebUtility.HtmlDecode(noTags);
    // Normalize whitespace
    noTags = Regex.Replace(noTags, @"\s+", " ").Trim();
    return noTags;
}

async Task<(bool ok, string? error, CookieContainer jar, string? customerPageHtml, Uri? baseUri)> BizdeskLoginAndAutoRoleAsync(string username, string password)
{
    var jar = new CookieContainer();
    using var http = CreateHttp(jar);

    var loginUri = new Uri(bizdeskLoginUrl);

    // 1) GET login page
    var get1 = await http.GetAsync(loginUri);
    var (_, html1, final1) = await FollowHtmlAsync(http, loginUri, get1);
    var baseUri = TryGetBizdeskBaseUri(final1) ?? TryGetBizdeskBaseUri(loginUri);
    if ((baseUri is null || IsLoginBaseUri(baseUri)) && !string.IsNullOrWhiteSpace(bizdeskTenant))
        baseUri = new Uri($"{loginUri.Scheme}://{loginUri.Host}/bizdesk/{bizdeskTenant.Trim('/')}/");

    if (string.IsNullOrWhiteSpace(html1))
        return (false, "Bizdesk login GET returned empty HTML.", jar, null, baseUri);

    var action = ExtractFormAction(html1);
    var postUri = string.IsNullOrWhiteSpace(action) ? loginUri : (new Uri(loginUri, action));

    // 2) POST credentials
    var f1 = ExtractInputs(html1);
    f1["__EVENTTARGET"] = loginEventTarget; // observed in HAR: btnLogin
    f1["__EVENTARGUMENT"] = "";
    f1["frmUsername"] = username;
    f1["frmPassword"] = password;

    var post1 = await http.PostAsync(postUri, new FormUrlEncodedContent(f1));
    var (_, html2, final2) = await FollowHtmlAsync(http, loginUri, post1);
    baseUri ??= TryGetBizdeskBaseUri(final2);
    baseUri ??= TryExtractBizdeskBaseUriFromHtml(html2, loginUri);
    if ((baseUri is null || IsLoginBaseUri(baseUri)) && !string.IsNullOrWhiteSpace(bizdeskTenant))
        baseUri = new Uri($"{loginUri.Scheme}://{loginUri.Host}/bizdesk/{bizdeskTenant.Trim('/')}/");

    if (string.IsNullOrWhiteSpace(html2))
        return (false, "Bizdesk login POST returned empty HTML (unexpected).", jar, null, baseUri);

    // If still login page, likely bad creds or wrong postback shape
    if (LooksLikeLoginPage(html2))
    {
        // Don't leak credentials; provide a small snippet
        return (false, $"Bizdesk login failed: server returned login page after POST (HTTP 200). Snippet:\n{Snip(html2)}", jar, null, baseUri);
    }

    // 3) Role selection page -> auto-select Kundsupport
    // From HAR: __EVENTTARGET=btnSetRole, frmRoles=3
    if (html2.Contains("frmRoles", StringComparison.OrdinalIgnoreCase) || html2.Contains(roleEventTarget, StringComparison.OrdinalIgnoreCase))
    {
        var f2 = ExtractInputs(html2);
        f2["__EVENTTARGET"] = roleEventTarget; // btnSetRole
        f2["__EVENTARGUMENT"] = "";
        f2["frmRoles"] = roleValue; // "3" = Kundsupport in HAR

        var post2 = await http.PostAsync(loginUri, new FormUrlEncodedContent(f2));
        var (_, html3, final3) = await FollowHtmlAsync(http, loginUri, post2);
        baseUri ??= TryGetBizdeskBaseUri(final3);
        baseUri ??= TryExtractBizdeskBaseUriFromHtml(html3, loginUri);
        if ((baseUri is null || IsLoginBaseUri(baseUri)) && !string.IsNullOrWhiteSpace(bizdeskTenant))
            baseUri = new Uri($"{loginUri.Scheme}://{loginUri.Host}/bizdesk/{bizdeskTenant.Trim('/')}/");

        if (string.IsNullOrWhiteSpace(html3))
            return (false, "Role selection POST returned empty HTML.", jar, null, baseUri);

        // After role selection we expect the customer selection page (DropDownListSupport)
        return (true, null, jar, html3, baseUri);
    }

    // If there was no role selection, maybe the user had only one role; still proceed.
    return (true, null, jar, html2, baseUri);
}

async Task<(bool ok, string? error, string? customerPageHtml, Uri? baseUri)> BizdeskSelectCustomerAsync(AppSession sess, string customerId)
{
    var jar = sess.UpstreamCookies;
    using var http = CreateHttp(jar);
    var loginUri = new Uri(bizdeskLoginUrl);
    var baseUri = sess.BizdeskBaseUri ?? TryGetBizdeskBaseUri(loginUri);
    if ((baseUri is null || IsLoginBaseUri(baseUri)) && !string.IsNullOrWhiteSpace(bizdeskTenant))
        baseUri = new Uri($"{loginUri.Scheme}://{loginUri.Host}/bizdesk/{bizdeskTenant.Trim('/')}/");

    // Use cached html if present, otherwise GET current customer selection page
    string html = sess.CustomerSelectionHtml ?? "";
    if (string.IsNullOrWhiteSpace(html))
    {
        var get = await http.GetAsync(loginUri);
        var (_, htmlGet, _) = await FollowHtmlAsync(http, loginUri, get);
        html = htmlGet ?? "";
    }

    if (string.IsNullOrWhiteSpace(html))
        return (false, "Could not load customer selection page HTML.", null, baseUri);

    // If we don't see the dropdown, we might already be past that step
    if (!html.Contains(customerField, StringComparison.OrdinalIgnoreCase))
        return (false, $"Customer dropdown '{customerField}' not found in HTML. You might already have a customer selected, or login/role selection failed.", html, baseUri);

    var f = ExtractInputs(html);
    f["__EVENTTARGET"] = customerEventTarget; // LinkButtonSupport
    f["__EVENTARGUMENT"] = "";
    f[customerField] = customerId;

    var post = await http.PostAsync(loginUri, new FormUrlEncodedContent(f));
    var (_, htmlAfter, finalAfter) = await FollowHtmlAsync(http, loginUri, post);
    baseUri ??= TryGetBizdeskBaseUri(finalAfter);
    baseUri ??= TryExtractBizdeskBaseUriFromHtml(htmlAfter, loginUri);
    if ((baseUri is null || IsLoginBaseUri(baseUri)) && !string.IsNullOrWhiteSpace(bizdeskTenant))
        baseUri = new Uri($"{loginUri.Scheme}://{loginUri.Host}/bizdesk/{bizdeskTenant.Trim('/')}/");

    if (string.IsNullOrWhiteSpace(htmlAfter))
        return (true, null, null, baseUri);

    // If the dropdown is still there, selection likely didn't apply
    if (htmlAfter.Contains(customerField, StringComparison.OrdinalIgnoreCase))
        return (false, "Customer selection did not advance (dropdown still present).", htmlAfter, baseUri);

    return (true, null, htmlAfter, baseUri);
}

// ---- API endpoints ----


static async Task<string> BizdeskGridPostAsync(HttpClient http, Uri findUri, string html, string eventArgument, int pageSize)
{
    var gridFields = ExtractInputs(html);
    gridFields["__EVENTTARGET"] = "ctl00$MPSPage_ContentPlaceHolder$mdResultsGrid1";
    gridFields["__EVENTARGUMENT"] = eventArgument;
    var pageSizeKey = FindKey(gridFields, k =>
        k.Contains("PageSizeComboBox", StringComparison.OrdinalIgnoreCase)
        && !k.Contains("ClientState", StringComparison.OrdinalIgnoreCase));
    if (!string.IsNullOrWhiteSpace(pageSizeKey))
        gridFields[pageSizeKey] = pageSize.ToString();

    var pageSizeStateKey = FindKey(gridFields, k =>
        k.Contains("PageSizeComboBox", StringComparison.OrdinalIgnoreCase)
        && k.Contains("ClientState", StringComparison.OrdinalIgnoreCase));
    if (!string.IsNullOrWhiteSpace(pageSizeStateKey))
    {
        gridFields[pageSizeStateKey] =
            $"{{\"logEntries\":[],\"value\":\"{pageSize}\",\"text\":\"{pageSize}\",\"enabled\":true,\"checkedIndices\":[],\"checkedItemsTextOverflows\":false}}";
    }

    var gridResp = await FollowAsync(http, new HttpRequestMessage(HttpMethod.Post, findUri)
    {
        Content = new FormUrlEncodedContent(gridFields)
    }, maxRedirects: 8);

    return await gridResp.Content.ReadAsStringAsync();
}

async Task<(bool ok, int status, object? payload, string? error)> BizdeskFetchGiftcardsAsync(
    AppSession session,
    string? poolCardTypeValue,
    string? poolCardTypeText,
    int page,
    int pageSize)
{
    try
    {
        using var http = CreateHttp(session.UpstreamCookies);

        // Prefer base URL detected after login/customer selection (contains tenant).
        var root = session.BizdeskBaseUri ?? new Uri(new Uri(bizdeskLoginUrl), "../../");
        if (IsLoginBaseUri(root) && !string.IsNullOrWhiteSpace(bizdeskTenant))
            root = new Uri($"{root.Scheme}://{root.Host}/bizdesk/{bizdeskTenant.Trim('/')}/");
        var findUri = new Uri(root, "cardaccount_find");

        // 1) GET the page (to get __VIEWSTATE etc)
        Log(session, $"Giftcards GET findUri={findUri}");
        var getResp = await FollowAsync(http, new HttpRequestMessage(HttpMethod.Get, findUri), maxRedirects: 8);
        var getHtml = await getResp.Content.ReadAsStringAsync();
        if (LooksLikeLoginPage(getHtml))
            return (false, 401, null, "Not logged in (Bizdesk returned login page).");

        var fields = ExtractInputs(getHtml);

        // 2) POST the search (same as clicking the Search button in Bizdesk)
        fields["__EVENTTARGET"] = "ctl00$MPSPage_ContentPlaceHolder$btnSearch";
        fields["__EVENTARGUMENT"] = "";

        // Optional: emulate the pool/card type selection captured in the HAR.
        if (!string.IsNullOrWhiteSpace(poolCardTypeValue) || !string.IsNullOrWhiteSpace(poolCardTypeText))
        {
            fields["ctl00$MPSPage_ContentPlaceHolder$SearchPoolcardtype$RadComboBoxSearch_Input"] = poolCardTypeText ?? "";
            fields["ctl00$MPSPage_ContentPlaceHolder$SearchPoolcardtype$RadComboBoxSearch_text"] = poolCardTypeText ?? "";
            fields["ctl00$MPSPage_ContentPlaceHolder$SearchPoolcardtype$RadComboBoxSearch_value"] = poolCardTypeValue ?? "";
        }

        Log(session, $"Giftcards POST search eventTarget=btnSearch poolFilter={(string.IsNullOrWhiteSpace(poolCardTypeValue) ? "off" : "on")}");
        var postResp = await FollowAsync(http, new HttpRequestMessage(HttpMethod.Post, findUri)
        {
            Content = new FormUrlEncodedContent(fields)
        }, maxRedirects: 8);

        var postHtml = await postResp.Content.ReadAsStringAsync();
        if (LooksLikeLoginPage(postHtml))
            return (false, 401, null, "Session expired while loading giftcards (Bizdesk returned login page).");

        const int bizdeskPageSize = 50;
        var htmlAfterSize = postHtml;
        if (bizdeskPageSize != 10)
        {
            var htmlSize = await BizdeskGridPostAsync(http, findUri, htmlAfterSize,
                $"FireCommand:ctl00$MPSPage_ContentPlaceHolder$mdResultsGrid1$ctl00;PageSize;{bizdeskPageSize}", bizdeskPageSize);
            if (!LooksLikeLoginPage(htmlSize))
                htmlAfterSize = htmlSize;
        }

        var pagerNames = ExtractPagerSubmitNames(htmlAfterSize);
        if (pagerNames.TryGetValue("first", out var firstName))
        {
            Log(session, $"Giftcards pager first submit={firstName}");
            var htmlFirst = await BizdeskPagerSubmitAsync(http, findUri, htmlAfterSize, firstName, bizdeskPageSize, session);
            if (!LooksLikeLoginPage(htmlFirst))
                htmlAfterSize = htmlFirst;
        }

        if (page > 1 && pagerNames.TryGetValue("next", out var nextName))
        {
            var hops = Math.Min(page - 1, 20);
            for (int i = 0; i < hops; i++)
            {
                Log(session, $"Giftcards pager next submit={nextName} hop={i + 1}/{hops}");
                var htmlNext = await BizdeskPagerSubmitAsync(http, findUri, htmlAfterSize, nextName, bizdeskPageSize, session);
                if (LooksLikeLoginPage(htmlNext))
                    break;
                htmlAfterSize = htmlNext;
            }
        }

        var htmlPage1 = htmlAfterSize;
        if (LooksLikeLoginPage(htmlPage1))
            return (false, 401, null, "Session expired while paging giftcards (Bizdesk returned login page).");

        var parsed1 = ParseGiftcardsFromCardAccountFindHtml(htmlPage1);
        Log(session, $"Giftcards parse page={page} returned={parsed1.Items.Count} totalItems={(parsed1.TotalItems?.ToString() ?? "null")}");
        if (parsed1.Items.Count == 0)
        {
            var parsedSearch = ParseGiftcardsFromCardAccountFindHtml(postHtml);
            if (parsedSearch.Items.Count > 0)
                parsed1 = parsedSearch;
        }

        var items = new List<GiftcardItem>(parsed1.Items);
        if (page == 1 && parsed1.Items.Count < bizdeskPageSize)
        {
            Log(session, "Giftcards fallback Page;0 and Page;1 to avoid last-page stickiness");
            var htmlPage0 = await BizdeskGridPostAsync(http, findUri, htmlAfterSize,
                "FireCommand:ctl00$MPSPage_ContentPlaceHolder$mdResultsGrid1$ctl00;Page;0", bizdeskPageSize);
            var htmlPage1b = await BizdeskGridPostAsync(http, findUri, htmlAfterSize,
                "FireCommand:ctl00$MPSPage_ContentPlaceHolder$mdResultsGrid1$ctl00;Page;1", bizdeskPageSize);

            if (!LooksLikeLoginPage(htmlPage0))
            {
                var parsed0 = ParseGiftcardsFromCardAccountFindHtml(htmlPage0);
                if (parsed0.Items.Count > items.Count)
                {
                    items = new List<GiftcardItem>(parsed0.Items);
                    parsed1 = parsed0;
                }
            }
            if (!LooksLikeLoginPage(htmlPage1b))
            {
                var parsed1b = ParseGiftcardsFromCardAccountFindHtml(htmlPage1b);
                if (parsed1b.Items.Count > items.Count)
                {
                    items = new List<GiftcardItem>(parsed1b.Items);
                    parsed1 = parsed1b;
                }
            }
        }
        int? totalItems = parsed1.TotalItems;
        int? totalPages = totalItems.HasValue ? (int)Math.Ceiling(totalItems.Value / (double)bizdeskPageSize) : null;

        var payload = new GiftcardParseResult
        {
            TotalItems = totalItems,
            Pages = totalPages,
            Returned = items.Count,
            Items = items
        };

        return (true, 200, payload, null);
    }
    catch (Exception ex)
    {
        Log(session, "Giftcards exception: " + ex.Message);
        return (false, 502, null, "Bizdesk giftcards fetch failed: " + ex.Message);
    }
}

async Task<(bool ok, int status, object? payload, string? error)> BizdeskFetchCardholdersAsync(AppSession session, int page, int pageSize, bool usePager, bool debugDump)
{
    try
    {
        using var http = CreateHttp(session.UpstreamCookies);
        var root = session.BizdeskBaseUri ?? new Uri(new Uri(bizdeskLoginUrl), "../../");
        if (IsLoginBaseUri(root) && !string.IsNullOrWhiteSpace(bizdeskTenant))
            root = new Uri($"{root.Scheme}://{root.Host}/bizdesk/{bizdeskTenant.Trim('/')}/");

        var findUri = new Uri(root, "cardholder_find");

        Log(session, $"Cardholders GET findUri={findUri}");
        var getResp = await FollowAsync(http, new HttpRequestMessage(HttpMethod.Get, findUri), maxRedirects: 8);
        var getHtml = await getResp.Content.ReadAsStringAsync();
        if (LooksLikeLoginPage(getHtml))
            return (false, 401, null, "Not logged in (Bizdesk returned login page).");
        session.LastCardholdersGetHtml = getHtml;
        var tsmFromGet = TryGetHiddenValue(getHtml, "ctl00_RadScriptManager1_TSM");
        if (string.IsNullOrEmpty(tsmFromGet) && !string.IsNullOrEmpty(bizdeskTsmFallback))
            tsmFromGet = bizdeskTsmFallback;

        var fields = ExtractInputs(getHtml);
        fields["__EVENTTARGET"] = "ctl00$MPSPage_ContentPlaceHolder$btnSearch";
        fields["__EVENTARGUMENT"] = "";
        if (!string.IsNullOrEmpty(tsmFromGet))
            fields["ctl00_RadScriptManager1_TSM"] = tsmFromGet;
        EnsureField(fields, "ctl00$MPSPage_ContentPlaceHolder$SearchPool$RadComboBoxSearch_clientWidth", "108px");
        EnsureField(fields, "ctl00$MPSPage_ContentPlaceHolder$SearchPool$RadComboBoxSearch_clientHeight", "17px");

        Log(session, "Cardholders POST search eventTarget=btnSearch");
        if (debugDump)
        {
            var nonEmpty = fields.Count(kv => !string.IsNullOrEmpty(kv.Value));
            var lines = new List<string> { $"POST search fields={fields.Count} nonEmpty={nonEmpty}" };
            foreach (var kv in fields)
            {
                var name = kv.Key;
                var val = kv.Value ?? "";
                if (name is "__VIEWSTATE" or "__EVENTVALIDATION")
                {
                    lines.Add($"{name}:len={val.Length}");
                    continue;
                }
                if (string.IsNullOrEmpty(val))
                {
                    lines.Add($"{name}:len=0");
                    continue;
                }
                var sample = val.Length > 120 ? val[..120] + "..." : val;
                lines.Add($"{name}:len={val.Length}={sample}");
            }
            session.LastCardholdersPostDebug = lines;
        }
        var postResp = await FollowAsync(http, new HttpRequestMessage(HttpMethod.Post, findUri)
        {
            Content = new FormUrlEncodedContent(fields)
        }, maxRedirects: 8);

        var postHtml = await postResp.Content.ReadAsStringAsync();
        if (LooksLikeLoginPage(postHtml))
            return (false, 401, null, "Session expired while loading cardholders (Bizdesk returned login page).");

        var html = postHtml;
        session.LastCardholdersSearchHtml = postHtml;
        var baseHtml = postHtml;
        if (pageSize != 10)
        {
            Log(session, $"Cardholders set pageSize={pageSize}");
            var htmlSize = await BizdeskGridPostAsync(http, findUri, baseHtml,
                $"FireCommand:ctl00$MPSPage_ContentPlaceHolder$mdResultsGrid1$ctl00;PageSize;{pageSize}", pageSize);
            if (!LooksLikeLoginPage(htmlSize))
            {
                html = htmlSize;
                baseHtml = htmlSize;
            }
        }
        session.LastCardholdersHtml = html;
        session.CardholderPageTargets = TryGetPageTargets(html);
        Log(session, $"Cardholders info={TryGetInfoPartText(html) ?? "n/a"} currentPage={TryGetCurrentPageFromHtml(html)?.ToString() ?? "n/a"} hasInfoPart={html.Contains("rgInfoPart", StringComparison.OrdinalIgnoreCase)} hasCurrentPage={html.Contains("rgCurrentPage", StringComparison.OrdinalIgnoreCase)}");
        if (usePager)
        {
            if (page > 1 && session.CardholderPageTargets is not null && session.CardholderPageTargets.TryGetValue(page, out var target))
            {
                Log(session, $"Cardholders pager page-link target={target.target} page={page}");
                Dictionary<string, string>? extra = null;
                if (!string.IsNullOrEmpty(tsmFromGet))
                {
                    extra = new Dictionary<string, string>
                    {
                        ["ctl00_RadScriptManager1_TSM"] = tsmFromGet,
                        ["ctl00$MPSPage_ContentPlaceHolder$SearchPool$RadComboBoxSearch_clientWidth"] = "108px",
                        ["ctl00$MPSPage_ContentPlaceHolder$SearchPool$RadComboBoxSearch_clientHeight"] = "17px"
                    };
                }
                var htmlFromTarget = await BizdeskPostBackAsync(http, findUri, baseHtml, target.target, target.arg, pageSize, debugDump ? session : null, "page-link", extra);
                if (!LooksLikeLoginPage(htmlFromTarget))
                {
                    html = htmlFromTarget;
                    var current = TryGetCurrentPageFromHtml(html);
                    Log(session, $"Cardholders after-page-link info={TryGetInfoPartText(html) ?? "n/a"} currentPage={current?.ToString() ?? "n/a"}");
                    if (!current.HasValue || current.Value != page)
                    {
                        Log(session, $"Cardholders page-link mismatch requested={page} got={(current?.ToString() ?? "n/a")}, trying grid Page${page}");
                        var htmlGrid = await BizdeskPostBackAsync(http, findUri, baseHtml, "ctl00$MPSPage_ContentPlaceHolder$mdResultsGrid1", $"Page${page}", pageSize, debugDump ? session : null, "grid-page", extra);
                        if (!LooksLikeLoginPage(htmlGrid))
                        {
                            html = htmlGrid;
                            Log(session, $"Cardholders after-grid info={TryGetInfoPartText(html) ?? "n/a"} currentPage={TryGetCurrentPageFromHtml(html)?.ToString() ?? "n/a"}");
                        }
                    }
                }
            }
        }

        Log(session, $"Cardholders before-parse info={TryGetInfoPartText(html) ?? "n/a"} currentPage={TryGetCurrentPageFromHtml(html)?.ToString() ?? "n/a"} hasInfoPart={html.Contains("rgInfoPart", StringComparison.OrdinalIgnoreCase)} hasCurrentPage={html.Contains("rgCurrentPage", StringComparison.OrdinalIgnoreCase)}");

        var parsed = ParseCardholdersFromCardholderFindHtml(html);
        return (true, 200, parsed, null);
    }
    catch (Exception ex)
    {
        Log(session, "Cardholders exception: " + ex.Message);
        return (false, 502, null, "Bizdesk cardholders fetch failed: " + ex.Message);
    }
}

async Task<(bool ok, int status, object? payload, string? error)> BizdeskFetchReportAsync(AppSession session, string reportGetPath, string reportPostPath, bool trySearch, int page, int pageSize, Dictionary<string, string>? searchOverrides = null)
{
    try
    {
        using var http = CreateHttp(session.UpstreamCookies);
        var root = session.BizdeskBaseUri ?? new Uri(new Uri(bizdeskLoginUrl), "../../");
        if (IsLoginBaseUri(root) && !string.IsNullOrWhiteSpace(bizdeskTenant))
            root = new Uri($"{root.Scheme}://{root.Host}/bizdesk/{bizdeskTenant.Trim('/')}/");

        var getUri = new Uri(root, reportGetPath);
        var postUri = new Uri(root, reportPostPath);
        var reportReferer = new Uri(root, "default");
        var cardholderReferer = new Uri(root, "cardholder_find");
        var giftcardsReferer = new Uri(root, "cardaccount_find");
        var reportRefererFallbacks = new[]
        {
            reportReferer,
            cardholderReferer,
            giftcardsReferer,
            root,
            new Uri(root, reportGetPath),
            new Uri(root, "Default.aspx")
        };

        static HttpRequestMessage MakeRequest(HttpMethod method, Uri uri, Uri? referer)
        {
            var req = new HttpRequestMessage(method, uri);
            if (referer is not null)
                req.Headers.Referrer = referer;
            return req;
        }

        foreach (var candidate in reportRefererFallbacks)
        {
            Log(session, $"Report warmup GET uri={candidate}");
            var warmResp = await FollowAsync(http, MakeRequest(HttpMethod.Get, candidate, candidate), maxRedirects: 8);
            var warmHtml = await warmResp.Content.ReadAsStringAsync();
            var warmIsError = LooksLikeBizdeskErrorPage(warmHtml);
            Log(session, $"Report warmup status={(int)warmResp.StatusCode} final={warmResp.RequestMessage?.RequestUri} errorPage={warmIsError}");
            if (warmResp.StatusCode == HttpStatusCode.OK && !warmIsError)
            {
                reportReferer = candidate;
                break;
            }
        }

        string html = string.Empty;
        Uri? reportPageUri = null;
        var reportKey = reportGetPath.Contains("customer", StringComparison.OrdinalIgnoreCase) ? "customer"
            : reportGetPath.Contains("transactions", StringComparison.OrdinalIgnoreCase) ? "transactions"
            : "report";
        foreach (var referer in reportRefererFallbacks)
        {
            Log(session, $"Report GET direct uri={postUri} referer={referer}");
            var directResp = await FollowAsync(http, MakeRequest(HttpMethod.Get, postUri, referer), maxRedirects: 8);
            var directHtml = await directResp.Content.ReadAsStringAsync();
            Log(session, $"Report GET direct status={(int)directResp.StatusCode} final={directResp.RequestMessage?.RequestUri}");
            if (!LooksLikeLoginPage(directHtml) && !LooksLikeBizdeskErrorPage(directHtml))
            {
                html = directHtml;
                reportReferer = referer;
                reportPageUri = postUri;
                break;
            }
        }

        if (string.IsNullOrWhiteSpace(html))
        {
            Log(session, $"Report GET {reportGetPath} uri={getUri}");
            var getResp = await FollowAsync(http, MakeRequest(HttpMethod.Get, getUri, reportReferer), maxRedirects: 8);
            var getHtml = await getResp.Content.ReadAsStringAsync();
            Log(session, $"Report GET status={(int)getResp.StatusCode} final={getResp.RequestMessage?.RequestUri}");
            if (LooksLikeLoginPage(getHtml))
                return (false, 401, null, "Not logged in (Bizdesk returned login page)." );
            if (!LooksLikeBizdeskErrorPage(getHtml))
            {
                html = getHtml;
                reportPageUri = getUri;
            }
        }

        if (string.IsNullOrWhiteSpace(html) && !Uri.Equals(getUri, postUri))
        {
            Log(session, $"Report GET alt uri={postUri}");
            var altResp = await FollowAsync(http, MakeRequest(HttpMethod.Get, postUri, reportReferer), maxRedirects: 8);
            var altHtml = await altResp.Content.ReadAsStringAsync();
            Log(session, $"Report GET alt status={(int)altResp.StatusCode} final={altResp.RequestMessage?.RequestUri}");
            if (!LooksLikeLoginPage(altHtml) && !LooksLikeBizdeskErrorPage(altHtml))
            {
                html = altHtml;
                reportPageUri = postUri;
            }
        }

        if (string.IsNullOrWhiteSpace(html))
        {
            var menuSourceUri = new Uri(root, "cardholder_find");
            var menuResp = await FollowAsync(http, MakeRequest(HttpMethod.Get, menuSourceUri, menuSourceUri), maxRedirects: 8);
            var menuHtml = await menuResp.Content.ReadAsStringAsync();
            if (!LooksLikeLoginPage(menuHtml) && !LooksLikeBizdeskErrorPage(menuHtml))
            {
                var menuItems = ExtractMenuPostbacks(menuHtml);
                var anchors = ExtractAnchors(menuHtml);
                var anchorCandidates = anchors
                    .Where(a =>
                        reportKey == "customer"
                            ? a.label.Contains("Kortinnehavare", StringComparison.OrdinalIgnoreCase)
                            : reportKey == "transactions"
                                ? a.label.Contains("Transaktionsrapport", StringComparison.OrdinalIgnoreCase)
                                : (a.label.Contains("Rapport", StringComparison.OrdinalIgnoreCase)
                                   || a.label.Contains("Report", StringComparison.OrdinalIgnoreCase)))
                    .ToList();

                foreach (var anchor in anchorCandidates)
                {
                    if (anchor.href.StartsWith("javascript:", StringComparison.OrdinalIgnoreCase)) continue;
                    var targetUri = new Uri(menuSourceUri, anchor.href);
                    Log(session, $"Report anchor candidate: {anchor.label} -> {targetUri}");
                    var anchorResp = await FollowAsync(http, MakeRequest(HttpMethod.Get, targetUri, menuSourceUri), maxRedirects: 8);
                    var anchorHtml = await anchorResp.Content.ReadAsStringAsync();
                    Log(session, $"Report anchor status={(int)anchorResp.StatusCode} final={anchorResp.RequestMessage?.RequestUri} errorPage={LooksLikeBizdeskErrorPage(anchorHtml)}");
                    if (!LooksLikeLoginPage(anchorHtml) && !LooksLikeBizdeskErrorPage(anchorHtml))
                    {
                        html = anchorHtml;
                        reportPageUri = targetUri;
                        break;
                    }
                }

                if (!string.IsNullOrWhiteSpace(html))
                    goto ReportPageReady;

                var candidates = menuItems
                    .Where(m =>
                        reportKey == "customer"
                            ? m.label.Contains("Kortinnehavare", StringComparison.OrdinalIgnoreCase)
                            : reportKey == "transactions"
                                ? m.label.Contains("Transaktion", StringComparison.OrdinalIgnoreCase)
                                : (m.label.Contains("Rapport", StringComparison.OrdinalIgnoreCase)
                                   || m.label.Contains("Report", StringComparison.OrdinalIgnoreCase)))
                    .ToList();

                if (candidates.Count > 0)
                {
                    Log(session, $"Report menu candidates: {string.Join(" | ", candidates.Select(c => $"{c.label}:{c.target}"))}");
                    foreach (var candidate in candidates)
                    {
                        var htmlFromMenu = await BizdeskPostBackAsync(http, menuSourceUri, menuHtml, candidate.target, candidate.argument, 0, session, "menu-report");
                        if (!LooksLikeLoginPage(htmlFromMenu) && !LooksLikeBizdeskErrorPage(htmlFromMenu))
                        {
                            html = htmlFromMenu;
                            break;
                        }
                    }
                }
                else
                {
                    Log(session, "Report menu candidates: none found");
                }
            }
        }

    ReportPageReady:
        var effectivePostUri = postUri;
        if (!string.IsNullOrWhiteSpace(html))
        {
            var action = ExtractFormAction(html);
            if (!string.IsNullOrWhiteSpace(action))
                effectivePostUri = new Uri(reportPageUri ?? postUri, action);
            else if (reportPageUri is not null)
                effectivePostUri = reportPageUri;
        }
        if (reportKey == "transactions"
            && reportPageUri is not null
            && !effectivePostUri.AbsolutePath.EndsWith("report_transactions.aspx", StringComparison.OrdinalIgnoreCase))
        {
            effectivePostUri = reportPageUri;
        }

        if (trySearch && (string.IsNullOrWhiteSpace(html) || !html.Contains("__VIEWSTATE", StringComparison.OrdinalIgnoreCase) || !html.Contains("btnSearch", StringComparison.OrdinalIgnoreCase)))
        {
            Log(session, $"Report POST bootstrap uri={postUri}");
            var bootstrapReq = MakeRequest(HttpMethod.Post, postUri, reportReferer);
            bootstrapReq.Content = new FormUrlEncodedContent(new Dictionary<string, string>
            {
                ["__EVENTTARGET"] = "ctl00$MPSPage_ContentPlaceHolder$btnSearch",
                ["__EVENTARGUMENT"] = ""
            });
            var bootstrapResp = await FollowAsync(http, bootstrapReq, maxRedirects: 8);
            var bootstrapHtml = await bootstrapResp.Content.ReadAsStringAsync();
            Log(session, $"Report POST bootstrap status={(int)bootstrapResp.StatusCode} final={bootstrapResp.RequestMessage?.RequestUri}");
            if (!LooksLikeLoginPage(bootstrapHtml) && !LooksLikeBizdeskErrorPage(bootstrapHtml) && bootstrapHtml.Contains("__VIEWSTATE", StringComparison.OrdinalIgnoreCase))
                html = bootstrapHtml;
        }

        if (trySearch && html.Contains("btnSearch", StringComparison.OrdinalIgnoreCase))
        {
            if (reportKey == "transactions" && searchOverrides is not null)
            {
                searchOverrides.TryGetValue("ctl00$MPSPage_ContentPlaceHolder$frmDateFrom", out var dateFromWarm);
                searchOverrides.TryGetValue("ctl00$MPSPage_ContentPlaceHolder$frmDateTo", out var dateToWarm);
                var hasDateRangeWarm = !string.IsNullOrWhiteSpace(dateFromWarm) || !string.IsNullOrWhiteSpace(dateToWarm);
                if (hasDateRangeWarm)
                {
                    var warmFields = ExtractInputs(html);
                    Log(session, $"Report tx warmup dateFrom={dateFromWarm ?? ""} dateTo={dateToWarm ?? ""} dateregion={warmFields.GetValueOrDefault("ctl00$MPSPage_ContentPlaceHolder$frmDateregion", "")}");
                    warmFields["__EVENTTARGET"] = "ctl00$MPSPage_ContentPlaceHolder$btnAdvancedSearch";
                    warmFields["__EVENTARGUMENT"] = "";
                    if (!string.IsNullOrEmpty(bizdeskTsmFallback))
                        EnsureField(warmFields, "ctl00_RadScriptManager1_TSM", bizdeskTsmFallback);
                    var warmReq = MakeRequest(HttpMethod.Post, effectivePostUri, reportPageUri ?? postUri);
                    warmReq.Content = new FormUrlEncodedContent(warmFields);
                    var warmResp = await FollowAsync(http, warmReq, maxRedirects: 8);
                    var warmHtml = await warmResp.Content.ReadAsStringAsync();
                    if (!LooksLikeLoginPage(warmHtml) && !LooksLikeBizdeskErrorPage(warmHtml))
                        html = warmHtml;
                }
            }

            var fields = ExtractInputs(html);
            fields["__EVENTTARGET"] = "ctl00$MPSPage_ContentPlaceHolder$btnSearch";
            fields["__EVENTARGUMENT"] = "";
            if (reportKey == "transactions")
            {
                // Some Bizdesk instances require this radio field for date-range queries.
                EnsureField(fields, "ctl00$MPSPage_ContentPlaceHolder$frmExcludeClearingTransaction", "Nej");
            }
            if (!string.IsNullOrEmpty(bizdeskTsmFallback))
                EnsureField(fields, "ctl00_RadScriptManager1_TSM", bizdeskTsmFallback);
            var pageSizeKey = FindKey(fields, k =>
                k.Contains("PageSizeComboBox", StringComparison.OrdinalIgnoreCase)
                && !k.Contains("ClientState", StringComparison.OrdinalIgnoreCase));
            var hasDateRange = false;
            string? dateFrom = null;
            string? dateTo = null;
            if (searchOverrides is not null)
            {
                foreach (var kv in searchOverrides)
                    fields[kv.Key] = kv.Value;
                searchOverrides.TryGetValue("ctl00$MPSPage_ContentPlaceHolder$frmDateFrom", out dateFrom);
                searchOverrides.TryGetValue("ctl00$MPSPage_ContentPlaceHolder$frmDateTo", out dateTo);
                hasDateRange = !string.IsNullOrWhiteSpace(dateFrom) || !string.IsNullOrWhiteSpace(dateTo);
                ApplyDateOverrides(fields, dateFrom, dateTo);
                // Keep frmDateregion unset when overriding dates; HAR with manual dates posts no dateregion keys.
            }
            if (!string.IsNullOrWhiteSpace(pageSizeKey))
            {
                if (pageSize > 0)
                    fields[pageSizeKey] = pageSize.ToString();
            }

            if (reportKey == "transactions")
            {
                // HAR includes clientWidth/clientHeight values for several Telerik inputs.
                // When missing, Bizdesk sometimes ignores other overrides (e.g. date range).
                foreach (var key in fields.Keys.ToList())
                {
                    if (!key.EndsWith("clientWidth", StringComparison.OrdinalIgnoreCase)
                        && !key.EndsWith("clientHeight", StringComparison.OrdinalIgnoreCase))
                        continue;
                    if (!string.IsNullOrWhiteSpace(fields[key])) continue;

                    var width = "109px";
                    if (key.Contains("SearchPool", StringComparison.OrdinalIgnoreCase)
                        || key.Contains("SearchPoolcardtype", StringComparison.OrdinalIgnoreCase))
                        width = "129px";
                    else if (key.Contains("frmStatus", StringComparison.OrdinalIgnoreCase)
                        || key.Contains("frmTerminalType", StringComparison.OrdinalIgnoreCase)
                        || key.Contains("frmShowOfflineTrans", StringComparison.OrdinalIgnoreCase))
                        width = "99px";

                    fields[key] = key.EndsWith("clientHeight", StringComparison.OrdinalIgnoreCase)
                        ? "17px"
                        : width;
                }
            }

            if (reportKey == "transactions")
            {
                EnsureTransactionReportFields(fields);
            }

            if (reportKey == "transactions")
            {
                var dateFieldKeys = fields.Keys
                    .Where(k => k.Contains("frmDate", StringComparison.OrdinalIgnoreCase) || k.Contains("Dateregion", StringComparison.OrdinalIgnoreCase))
                    .OrderBy(k => k)
                    .ToList();
                if (dateFieldKeys.Count > 0)
                {
                    var shown = dateFieldKeys.Take(12)
                        .Select(k => $"{k}={fields.GetValueOrDefault(k, "")}");
                    var more = dateFieldKeys.Count > 12 ? $" +{dateFieldKeys.Count - 12} more" : "";
                    Log(session, $"Report tx date-fields {dateFieldKeys.Count}: {string.Join(" | ", shown)}{more}");
                }

                var drOptions = ExtractSelectOptions(html, "ctl00$MPSPage_ContentPlaceHolder$frmDateregion");
                if (drOptions.Count == 0)
                    drOptions = ExtractRadComboBoxItems(html, "frmDateregion");
                if (drOptions.Count > 0)
                {
                    var optSample = string.Join(", ", drOptions.Take(6).Select(o => $"{o.label}:{o.value}"));
                    var more = drOptions.Count > 6 ? $" +{drOptions.Count - 6} more" : "";
                    Log(session, $"Report tx dateregion options count={drOptions.Count} sample={optSample}{more}");
                }
                else
                {
                    Log(session, "Report tx dateregion options count=0");
                }

                if (hasDateRange)
                    Log(session, $"Report tx override dateFrom={dateFrom ?? ""} dateTo={dateTo ?? ""}");
            }

            if (reportKey == "transactions" && hasDateRange)
            {
                var removedKeys = fields.Keys
                    .Where(k => k.Contains("frmDateregion", StringComparison.OrdinalIgnoreCase))
                    .ToList();
                foreach (var key in removedKeys)
                    fields.Remove(key);
                if (removedKeys.Count > 0)
                    Log(session, $"Report dateregion removed fields={removedKeys.Count}");

                var picked = TryPickDateregionOption(html);
                if (picked is { } option && !string.IsNullOrWhiteSpace(option.value))
                {
                    fields["ctl00$MPSPage_ContentPlaceHolder$frmDateregion_Input"] = option.label;
                    fields["ctl00$MPSPage_ContentPlaceHolder$frmDateregion_text"] = option.label;
                    fields["ctl00$MPSPage_ContentPlaceHolder$frmDateregion_value"] = option.value;
                    EnsureField(fields, "ctl00$MPSPage_ContentPlaceHolder$frmDateregion_clientWidth", "109px");
                    EnsureField(fields, "ctl00$MPSPage_ContentPlaceHolder$frmDateregion_clientHeight", "17px");
                    Log(session, $"Report dateregion set to {option.label} ({option.value}) for explicit date range");
                }
                else
                {
                    Log(session, "Report dateregion cleared (no suitable option found) for explicit date range");
                }
            }

            var postReq = MakeRequest(HttpMethod.Post, effectivePostUri, reportPageUri ?? postUri);
            if (searchOverrides is not null && session is not null)
            {
                var nonEmpty = fields.Count(kv => !string.IsNullOrEmpty(kv.Value));
                var lines = new List<string> { $"POST report-search fields={fields.Count} nonEmpty={nonEmpty}" };
                foreach (var kv in fields)
                {
                    var name = kv.Key;
                    var val = kv.Value ?? "";
                    if (name is "__VIEWSTATE" or "__EVENTVALIDATION")
                    {
                        lines.Add($"{name}:len={val.Length}");
                        continue;
                    }
                    if (string.IsNullOrEmpty(val))
                    {
                        lines.Add($"{name}:len=0");
                        continue;
                    }
                    var sample = val.Length > 120 ? val[..120] + "..." : val;
                    lines.Add($"{name}:len={val.Length}={sample}");
                }
                session.LastReportPostDebug = lines;
            }
            postReq.Content = new FormUrlEncodedContent(fields);
            var postResp = await FollowAsync(http, postReq, maxRedirects: 8);

            var postHtml = await postResp.Content.ReadAsStringAsync();
            Log(session, $"Report POST status={(int)postResp.StatusCode} final={postResp.RequestMessage?.RequestUri}");
            if (!LooksLikeLoginPage(postHtml) && !LooksLikeBizdeskErrorPage(postHtml))
                html = postHtml;
            else if (reportKey == "transactions")
            {
                var altPostUri = reportPageUri ?? new Uri(root, "report_transactions.aspx");
                if (!Uri.Equals(altPostUri, effectivePostUri))
                {
                    Log(session, $"Report POST retry uri={altPostUri}");
                    var retryReq = MakeRequest(HttpMethod.Post, altPostUri, reportPageUri ?? postUri);
                    retryReq.Content = new FormUrlEncodedContent(fields);
                    var retryResp = await FollowAsync(http, retryReq, maxRedirects: 8);
                    var retryHtml = await retryResp.Content.ReadAsStringAsync();
                    Log(session, $"Report POST retry status={(int)retryResp.StatusCode} final={retryResp.RequestMessage?.RequestUri}");
                    if (!LooksLikeLoginPage(retryHtml) && !LooksLikeBizdeskErrorPage(retryHtml))
                        html = retryHtml;
                }
            }
        }

        if (pageSize > 0 && !string.IsNullOrWhiteSpace(html))
        {
            var gridTarget = reportKey == "transactions"
                ? "ctl00$MPSPage_ContentPlaceHolder$RadGridTransaction"
                : "ctl00$MPSPage_ContentPlaceHolder$mdResultsGrid1";
            var pageSizeArg = reportKey == "transactions"
                ? $"FireCommand:ctl00$MPSPage_ContentPlaceHolder$RadGridTransaction$ctl00;PageSize;{pageSize}"
                : $"FireCommand:ctl00$MPSPage_ContentPlaceHolder$mdResultsGrid1$ctl00;PageSize;{pageSize}";
            html = await BizdeskPostBackAsync(http, effectivePostUri, html, gridTarget, pageSizeArg, pageSize, session, "report-pagesize");
        }

        if (page > 1 && !string.IsNullOrWhiteSpace(html))
        {
            var gridTarget = reportKey == "transactions"
                ? "ctl00$MPSPage_ContentPlaceHolder$RadGridTransaction"
                : "ctl00$MPSPage_ContentPlaceHolder$mdResultsGrid1";
            html = await BizdeskPostBackAsync(http, effectivePostUri, html, gridTarget, $"Page${page}", pageSize, session, "report-page");
        }

        if (!string.IsNullOrWhiteSpace(html))
        {
            session.LastReportCustomerHtml = reportGetPath.Contains("report_customer", StringComparison.OrdinalIgnoreCase) ? html : session.LastReportCustomerHtml;
            session.LastReportTransactionsHtml = reportGetPath.Contains("report_transactions", StringComparison.OrdinalIgnoreCase) ? html : session.LastReportTransactionsHtml;
        }
        var parsed = ParseReportTableHtml(html);
        return (true, 200, parsed, null);
    }
    catch (Exception ex)
    {
        Log(session, "Report exception: " + ex.Message);
        return (false, 502, null, "Bizdesk report fetch failed: " + ex.Message);
    }
}

app.MapPost("/api/auth/login", async (HttpContext ctx, LoginRequest req) =>
{
    if (string.IsNullOrWhiteSpace(req.Username) || string.IsNullOrWhiteSpace(req.Password))
        return Results.BadRequest(new { error = "Missing username or password." });

    var (ok, error, jar, customerHtml, baseUri) = await BizdeskLoginAndAutoRoleAsync(req.Username, req.Password);
    if (!ok)
        return Results.Json(new { error }, statusCode: StatusCodes.Status401Unauthorized);

    var sid = NewSessionId();
    sessions[sid] = new AppSession
    {
        Username = req.Username,
        Role = "Kundsupport",
        UpstreamCookies = jar,
        CustomerSelectionHtml = customerHtml,
        BizdeskBaseUri = baseUri
    };
    SetSessionCookie(ctx, sid);

    return Results.Ok(new { authenticated = true, role = "Kundsupport", needsCustomer = true });
});

app.MapGet("/api/auth/me", (HttpContext ctx) =>
{
    var sid = GetSessionId(ctx);
    if (sid is null || !sessions.TryGetValue(sid, out var sess))
        return Results.Unauthorized();

    return Results.Ok(new
    {
        authenticated = true,
        username = sess.Username,
        role = sess.Role,
        selectedCustomerId = sess.SelectedCustomerId,
        selectedCustomerLabel = sess.SelectedCustomerLabel
    });
});

app.MapPost("/api/auth/logout", (HttpContext ctx) =>
{
    var sid = GetSessionId(ctx);
    if (sid is not null) sessions.TryRemove(sid, out _);
    ClearSessionCookie(ctx);
    return Results.Ok(new { ok = true });
});

app.MapGet("/api/bizdesk/customers", (HttpContext ctx) =>
{
    var sid = GetSessionId(ctx);
    if (sid is null || !sessions.TryGetValue(sid, out var sess))
        return Results.Unauthorized();

    var html = sess.CustomerSelectionHtml ?? "";
    if (string.IsNullOrWhiteSpace(html))
        return Results.Json(new { error = "No customer selection HTML cached. Try logging in again." }, statusCode: 400);

    var options = ExtractSelectOptions(html, customerField);
    var customers = options.Select(o => new { value = o.value, label = o.label }).ToList();
    return Results.Ok(new { customers });
});


app.MapGet("/api/bizdesk/giftcards", async (HttpRequest req) =>
{
    if (!TryGetSession(req, out var session, out var errorResult))
        return errorResult;

    if (string.IsNullOrWhiteSpace(session.SelectedCustomerId))
        return Results.Json(new { error = "No customer selected. Select a customer first." }, statusCode: 400);

    var usePoolFilter = builder.Configuration.GetValue<bool>("Bizdesk:GiftcardsSearch:UsePoolCardTypeFilter");
    var poolValue = usePoolFilter ? builder.Configuration["Bizdesk:GiftcardsSearch:PoolCardTypeValue"] : null;
    var poolText = usePoolFilter ? builder.Configuration["Bizdesk:GiftcardsSearch:PoolCardTypeText"] : null;

    var page = int.TryParse(req.Query["page"], out var p) ? p : 1;
    var pageSize = int.TryParse(req.Query["pageSize"], out var ps) ? ps : 50;
    if (page < 1) page = 1;
    if (pageSize < 1) pageSize = 50;
    if (pageSize > 50) pageSize = 50;

    var result = await BizdeskFetchGiftcardsAsync(session, poolValue, poolText, page, pageSize);

    if (!result.ok)
        return Results.Json(new { error = result.error ?? "Failed to load giftcards." }, statusCode: result.status);

    return Results.Ok(result.payload);
});

app.MapGet("/api/bizdesk/users", async (HttpRequest req) =>
{
    if (!TryGetSession(req, out var session, out var errorResult))
        return errorResult;

    if (string.IsNullOrWhiteSpace(session.SelectedCustomerId))
        return Results.Json(new { error = "No customer selected. Select a customer first." }, statusCode: 400);

    var page = int.TryParse(req.Query["page"], out var p) ? p : 1;
    var pageSize = int.TryParse(req.Query["pageSize"], out var ps) ? ps : 50;
    var usePager = req.Query.TryGetValue("pager", out var pv) && pv.ToString() == "1";
    var debugDump = req.Query.TryGetValue("debug", out var dv) && dv.ToString() == "1";
    if (page < 1) page = 1;
    if (pageSize < 1) pageSize = 50;
    if (pageSize > 50) pageSize = 50;

    var result = await BizdeskFetchCardholdersAsync(session, page, pageSize, usePager, debugDump);

    if (!result.ok)
        return Results.Json(new { error = result.error ?? "Failed to load users." }, statusCode: result.status);

    return Results.Ok(result.payload);
});
app.MapGet("/api/bizdesk/report/cardholders", async (HttpRequest req) =>
{
    if (!TryGetSession(req, out var session, out var errorResult))
        return errorResult;

    if (string.IsNullOrWhiteSpace(session.SelectedCustomerId))
        return Results.Json(new { error = "No customer selected. Select a customer first." }, statusCode: 400);

    var page = Math.Max(1, int.TryParse(req.Query["page"], out var p) ? p : 1);
    var pageSize = Math.Max(1, int.TryParse(req.Query["pageSize"], out var ps) ? ps : 50);
    if (pageSize > 50) pageSize = 50;
    var result = await BizdeskFetchReportAsync(session, "report_customer.aspx", "report_customer", true, page, pageSize);

    if (!result.ok)
        return Results.Json(new { error = result.error ?? "Failed to load report." }, statusCode: result.status);

    return Results.Ok(result.payload);
});

app.MapGet("/api/bizdesk/report/transactions", async (HttpRequest req) =>
{
    if (!TryGetSession(req, out var session, out var errorResult))
        return errorResult;

    if (string.IsNullOrWhiteSpace(session.SelectedCustomerId))
        return Results.Json(new { error = "No customer selected. Select a customer first." }, statusCode: 400);

    var page = Math.Max(1, int.TryParse(req.Query["page"], out var p) ? p : 1);
    var pageSize = Math.Max(1, int.TryParse(req.Query["pageSize"], out var ps) ? ps : 50);
    if (pageSize > 50) pageSize = 50;
    var dateFrom = req.Query["dateFrom"].ToString();
    var dateTo = req.Query["dateTo"].ToString();
    Dictionary<string, string>? overrides = null;
    if (!string.IsNullOrWhiteSpace(dateFrom) || !string.IsNullOrWhiteSpace(dateTo))
    {
        overrides = new Dictionary<string, string>();
        if (!string.IsNullOrWhiteSpace(dateFrom))
        {
            overrides["ctl00$MPSPage_ContentPlaceHolder$frmDateFrom"] = dateFrom;
            overrides["ctl00$MPSPage_ContentPlaceHolder$frmDateFrom$dateInput"] = dateFrom;
        }
        if (!string.IsNullOrWhiteSpace(dateTo))
        {
            overrides["ctl00$MPSPage_ContentPlaceHolder$frmDateTo"] = dateTo;
            overrides["ctl00$MPSPage_ContentPlaceHolder$frmDateTo$dateInput"] = dateTo;
        }
        overrides["ctl00_MPSPage_ContentPlaceHolder_RadGridTransaction_ClientState"] = "";
    }
    var forceSearch = overrides is not null;
    var debug = req.Query.TryGetValue("debug", out var dv) && dv.ToString() == "1";
    var result = await BizdeskFetchReportAsync(session, "report_transactions.aspx", "report_transactions.aspx", forceSearch, page, pageSize, overrides);

    if (!result.ok)
        return Results.Json(new { error = result.error ?? "Failed to load report." }, statusCode: result.status);

    if (debug)
    {
        var reportHtml = session.LastReportTransactionsHtml ?? "";
        var reportInputs = string.IsNullOrWhiteSpace(reportHtml) ? new Dictionary<string, string>() : ExtractInputs(reportHtml);
        reportInputs.TryGetValue("ctl00$MPSPage_ContentPlaceHolder$frmDateregion", out var dateregionSelected);
        List<object> dateregionOptions;
        if (string.IsNullOrWhiteSpace(reportHtml))
        {
            dateregionOptions = new List<object>();
        }
        else
        {
            var selectOptions = ExtractSelectOptions(reportHtml, "ctl00$MPSPage_ContentPlaceHolder$frmDateregion")
                .Select(o => new { value = o.value, label = o.label })
                .Cast<object>()
                .ToList();
            if (selectOptions.Count > 0)
            {
                dateregionOptions = selectOptions;
            }
            else
            {
                dateregionOptions = ExtractRadComboBoxItems(reportHtml, "frmDateregion")
                    .Select(o => new { value = o.value, label = o.label })
                    .Cast<object>()
                    .ToList();
            }
        }
        var dateFieldNames = reportInputs.Keys
            .Where(k => k.Contains("frmDate", StringComparison.OrdinalIgnoreCase))
            .OrderBy(k => k)
            .ToArray();
        var dateregionFieldNames = reportInputs.Keys
            .Where(k => k.Contains("Dateregion", StringComparison.OrdinalIgnoreCase))
            .OrderBy(k => k)
            .ToArray();
        return Results.Ok(new
        {
            payload = result.payload,
            postDebug = session.LastReportPostDebug?.ToArray() ?? Array.Empty<string>(),
            logs = session.Logs.ToArray(),
            dateregionSelected,
            dateregionOptions,
            formAction = ExtractFormAction(reportHtml),
            dateFieldNames,
            dateregionFieldNames,
            dateregionInputValue = TryGetHiddenValue(reportHtml, "ctl00$MPSPage_ContentPlaceHolder$frmDateregion_Input"),
            dateregionClientState = TryGetHiddenValue(reportHtml, "ctl00_MPSPage_ContentPlaceHolder_frmDateregion_ClientState"),
            dateregionScript = Snip(TryGetScriptBlockContaining(reportHtml, "frmDateregion"), 2000),
            snippetDateFrom = TryGetSnippetAround(reportHtml, "frmDateFrom", 800),
            snippetDateregion = TryGetSnippetAround(reportHtml, "Dateregion", 2000)
        });
    }

    return Results.Ok(result.payload);
});

app.MapGet("/api/bizdesk/giftcards/debug", async (HttpRequest req) =>
{
    if (!TryGetSession(req, out var session, out var errorResult))
        return errorResult;

    try
    {
        using var http = CreateHttp(session.UpstreamCookies);
        var root = session.BizdeskBaseUri ?? new Uri(new Uri(bizdeskLoginUrl), "../../");
        if (IsLoginBaseUri(root) && !string.IsNullOrWhiteSpace(bizdeskTenant))
            root = new Uri($"{root.Scheme}://{root.Host}/bizdesk/{bizdeskTenant.Trim('/')}/");
        var findUri = new Uri(root, "cardaccount_find");

        var getResp = await http.GetAsync(findUri);
        var (resp, html, finalUri) = await FollowHtmlAsync(http, findUri, getResp);

        return Results.Ok(new
        {
            baseUri = root.ToString(),
            findUri = findUri.ToString(),
            finalUri = finalUri.ToString(),
            status = (int)resp.StatusCode,
            looksLikeLogin = LooksLikeLoginPage(html ?? ""),
            snippet = Snip(html, 2000),
            logs = session.Logs.ToArray()
        });
    }
    catch (Exception ex)
    {
        return Results.Json(new { error = ex.Message }, statusCode: 500);
    }
});

app.MapGet("/api/bizdesk/users/debug", async (HttpRequest req) =>
{
    if (!TryGetSession(req, out var session, out var errorResult))
        return errorResult;

    var html = session.LastCardholdersHtml ?? "";
    return Results.Ok(new
    {
        logs = session.Logs.ToArray(),
        postDebug = session.LastCardholdersPostDebug,
        pageTargets = session.CardholderPageTargets is null
            ? null
            : session.CardholderPageTargets
                .OrderBy(kv => kv.Key)
                .Take(12)
                .ToDictionary(kv => kv.Key, kv => kv.Value.target),
        hasInfoPart = html.Contains("rgInfoPart", StringComparison.OrdinalIgnoreCase),
        hasCurrentPage = html.Contains("rgCurrentPage", StringComparison.OrdinalIgnoreCase),
        infoPart = TryGetInfoPartText(html),
        currentPage = TryGetCurrentPageFromHtml(html),
        tsmLen = TryGetHiddenValue(html, "ctl00_RadScriptManager1_TSM")?.Length ?? 0,
        viewstateLen = TryGetHiddenValue(html, "__VIEWSTATE")?.Length ?? 0,
        tsmLenGet = TryGetHiddenValue(session.LastCardholdersGetHtml ?? "", "ctl00_RadScriptManager1_TSM")?.Length ?? 0,
        viewstateLenGet = TryGetHiddenValue(session.LastCardholdersGetHtml ?? "", "__VIEWSTATE")?.Length ?? 0,
        tsmLenSearch = TryGetHiddenValue(session.LastCardholdersSearchHtml ?? "", "ctl00_RadScriptManager1_TSM")?.Length ?? 0,
        viewstateLenSearch = TryGetHiddenValue(session.LastCardholdersSearchHtml ?? "", "__VIEWSTATE")?.Length ?? 0,
        tsmSnippetGet = TryGetSnippetAround(session.LastCardholdersGetHtml ?? "", "RadScriptManager1_TSM"),
        infoSnippet = TryGetSnippetAround(html, "rgInfoPart"),
        pagerSnippet = TryGetSnippetAround(html, "rgNumPart"),
        currentPageSnippet = TryGetSnippetAround(html, "rgCurrentPage")
    });
});

app.MapPost("/api/bizdesk/customers/select", async (HttpContext ctx, SelectCustomerRequest req) =>
{
    var sid = GetSessionId(ctx);
    if (sid is null || !sessions.TryGetValue(sid, out var sess))
        return Results.Unauthorized();

    if (string.IsNullOrWhiteSpace(req.CustomerId))
        return Results.BadRequest(new { error = "Missing customerId." });

    // Lookup label from cached HTML options (if available)
    var options = ExtractSelectOptions(sess.CustomerSelectionHtml ?? "", customerField);
    var label = options.FirstOrDefault(o => o.value == req.CustomerId).label;

    var (ok, error, htmlAfter, baseUri) = await BizdeskSelectCustomerAsync(sess, req.CustomerId);
    if (!ok)
        return Results.Json(new { error, snippet = Snip(htmlAfter) }, statusCode: 400);

    sess.SelectedCustomerId = req.CustomerId;
    sess.SelectedCustomerLabel = string.IsNullOrWhiteSpace(label) ? req.CustomerId : label;
    sess.CustomerSelectionHtml = htmlAfter ?? sess.CustomerSelectionHtml;
    sess.BizdeskBaseUri = baseUri ?? sess.BizdeskBaseUri;

    return Results.Ok(new { ok = true, selectedCustomerId = sess.SelectedCustomerId, selectedCustomerLabel = sess.SelectedCustomerLabel });
});

app.MapGet("/api/bizdesk/customers/debug", (HttpContext ctx) =>
{
    var sid = GetSessionId(ctx);
    if (sid is null || !sessions.TryGetValue(sid, out var sess))
        return Results.Unauthorized();

    var html = sess.CustomerSelectionHtml ?? "";
    return Results.Ok(new
    {
        hasHtml = !string.IsNullOrWhiteSpace(html),
        looksLikeLogin = LooksLikeLoginPage(html),
        containsRoles = html.Contains("frmRoles", StringComparison.OrdinalIgnoreCase),
        containsCustomerDropdown = html.Contains(customerField, StringComparison.OrdinalIgnoreCase),
        baseUri = sess.BizdeskBaseUri?.ToString(),
        snippet = Snip(html, 2000)
    });
});

app.Run();

// ---- DTOs / session ----
record LoginRequest(string Username, string Password);
record SelectCustomerRequest(string CustomerId);

class AppSession
{
    public string Username { get; init; } = "";
    public string Role { get; init; } = "";
    public CookieContainer UpstreamCookies { get; init; } = new CookieContainer();
    public string? SelectedCustomerId { get; set; }
    public string? SelectedCustomerLabel { get; set; }
    public string? CustomerSelectionHtml { get; set; }
    public Uri? BizdeskBaseUri { get; set; }
    public ConcurrentQueue<string> Logs { get; } = new();
    public string? LastCardholdersHtml { get; set; }
    public string? LastCardholdersGetHtml { get; set; }
    public string? LastCardholdersSearchHtml { get; set; }
    public Dictionary<int, (string target, string arg)>? CardholderPageTargets { get; set; }
    public List<string>? LastCardholdersPostDebug { get; set; }
    public string? LastReportCustomerHtml { get; set; }
    public string? LastReportTransactionsHtml { get; set; }
    public List<string>? LastReportPostDebug { get; set; }
}


record GiftcardItem(
    string AccountNo,
    string CardTypeName,
    string CardLabel,
    string CardNumber,
    string StartDate,
    string Balance,
    string InternalId);

class GiftcardParseResult
{
    public int? TotalItems { get; set; }
    public int? Pages { get; set; }
    public int Returned { get; set; }
    public List<GiftcardItem> Items { get; set; } = new();
}
