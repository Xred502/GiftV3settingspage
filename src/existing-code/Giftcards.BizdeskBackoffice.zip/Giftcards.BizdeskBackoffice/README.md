# Giftcards Backoffice (Technical Prototype) — Local demo

This project demonstrates **headless Bizdesk login** (ASP.NET WebForms), automatic role selection (Kundsupport), and customer selection.

## Prerequisites
- .NET 8 SDK
- Network access to https://dittkort.se/

## Run locally
1. Open a terminal in the folder that contains `Giftcards.BizdeskBackoffice.csproj`
2. Run:
   - `dotnet restore`
   - `dotnet run`
3. Open:
   - http://localhost:5080/giftcards/

> Note: The app uses PathBase `/giftcards` to match your intended production path.

## What happens during login
Server-side (your browser never sees Bizdesk cookies):
1. GET Bizdesk login page to collect `__VIEWSTATE`, `__EVENTVALIDATION`, cookies.
2. POST credentials with `__EVENTTARGET=btnLogin`.
3. Parse role selection page, then POST `frmRoles=3` with `__EVENTTARGET=btnSetRole` (Kundsupport).
4. Parse customer selection page for `<select name="DropDownListSupport">`.

## Config
`appsettings.json` contains:
- `Bizdesk:LoginUrl` (default: https://dittkort.se/bizdesk/login/login)
- `Bizdesk:AutoRoleValue` (default: "3" = Kundsupport as observed in your HAR)

## Security
- Passwords are never logged.
- Bizdesk cookies are stored server-side in the demo session.



## Notes
- Role is auto-selected to Kundsupport after login.
- Customer list is fetched immediately after login (no manual role step in UI).
- Giftcards listing is implemented by emulating Bizdesk's `cardaccount_find` search (WebForms postback) and parsing the RadGrid HTML.
- Current limitation: returns only the first page (Bizdesk paging can be added later if needed).
- Configure default pool/card type filter via `Bizdesk:GiftcardsSearch` in `appsettings.json`.
